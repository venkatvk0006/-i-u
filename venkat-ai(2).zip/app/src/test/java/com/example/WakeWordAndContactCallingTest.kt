package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.calling.CallManager
import com.example.calling.CallResult
import com.example.calling.ContactItem
import com.example.calling.ContactMatcher
import com.example.calling.ContactPhoneNumber
import com.example.calling.VoiceCommandParser
import com.example.wakeword.WakeWordEngine
import com.example.wakeword.WakeWordEngineStatus
import com.example.wakeword.WakeWordSettings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import com.example.util.ActionType
import com.example.util.DeviceDutyManager
import com.example.util.DutyResult
import com.example.wakeword.WakeWordOption
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class WakeWordAndContactCallingTest {

    private val context: Context
        get() = ApplicationProvider.getApplicationContext()

    @Test
    fun testVoiceCommandParserEnglish() {
        val result1 = VoiceCommandParser.parseCallCommand("Call Arun")
        assertTrue(result1.isCallIntent)
        assertEquals("arun", result1.targetNameOrNumber)
        assertFalse(result1.isDirectNumber)

        val result2 = VoiceCommandParser.parseCallCommand("Dial 9876543210")
        assertTrue(result2.isCallIntent)
        assertEquals("9876543210", result2.targetNameOrNumber)
        assertTrue(result2.isDirectNumber)

        // Wake phrase prefix calling
        val jarvisCall = VoiceCommandParser.parseCallCommand("Hey Jarvis, call Arun")
        assertTrue(jarvisCall.isCallIntent)
        assertEquals("arun", jarvisCall.targetNameOrNumber)

        val siriCall = VoiceCommandParser.parseCallCommand("Hey Siri, call John")
        assertTrue(siriCall.isCallIntent)
        assertEquals("john", siriCall.targetNameOrNumber)

        val jarviseDirect = VoiceCommandParser.parseCallCommand("hey jarvise call 9876543210")
        assertTrue(jarviseDirect.isCallIntent)
        assertEquals("9876543210", jarviseDirect.targetNameOrNumber)
        assertTrue(jarviseDirect.isDirectNumber)
    }

    @Test
    fun testVoiceCommandParserTamil() {
        val result1 = VoiceCommandParser.parseCallCommand("அம்மாவுக்கு கால் செய்")
        assertTrue(result1.isCallIntent)
        assertEquals("TA", result1.detectedLanguage)
        assertEquals("அம்மாவுக்கு", result1.targetNameOrNumber)

        val result2 = VoiceCommandParser.parseCallCommand("ரமேஷுக்கு கால் பண்ணு")
        assertTrue(result2.isCallIntent)
        assertEquals("ரமேஷுக்கு", result2.targetNameOrNumber)

        // Wake phrase prefix calling in Tamil
        val tamilCall = VoiceCommandParser.parseCallCommand("HEY TAMIL அம்மாவுக்கு கால் செய்")
        assertTrue(tamilCall.isCallIntent)
        assertEquals("அம்மாவுக்கு", tamilCall.targetNameOrNumber)
    }

    @Test
    fun testVoiceCommandParserHindi() {
        val result1 = VoiceCommandParser.parseCallCommand("माँ को कॉल करो")
        assertTrue(result1.isCallIntent)
        assertEquals("HI", result1.detectedLanguage)
        assertEquals("माँ को", result1.targetNameOrNumber)

        val result2 = VoiceCommandParser.parseCallCommand("अरुण को फोन लगाओ")
        assertTrue(result2.isCallIntent)
        assertEquals("अरुण को", result2.targetNameOrNumber)
    }

    @Test
    fun testVoiceConfirmationResponses() {
        // English
        assertTrue(VoiceCommandParser.isConfirmationAffirmative("yes"))
        assertTrue(VoiceCommandParser.isConfirmationAffirmative("call"))
        assertTrue(VoiceCommandParser.isConfirmationCancellation("cancel"))
        assertTrue(VoiceCommandParser.isConfirmationCancellation("no"))

        // Tamil
        assertTrue(VoiceCommandParser.isConfirmationAffirmative("ஆமாம்"))
        assertTrue(VoiceCommandParser.isConfirmationAffirmative("ஆம்"))
        assertTrue(VoiceCommandParser.isConfirmationCancellation("வேண்டாம்"))
        assertTrue(VoiceCommandParser.isConfirmationCancellation("இல்லை"))

        // Hindi
        assertTrue(VoiceCommandParser.isConfirmationAffirmative("हाँ"))
        assertTrue(VoiceCommandParser.isConfirmationAffirmative("कॉल करो"))
        assertTrue(VoiceCommandParser.isConfirmationCancellation("नहीं"))
        assertTrue(VoiceCommandParser.isConfirmationCancellation("रद्द करो"))
    }

    @Test
    fun testContactMatcherTamilSuffixStrippingAndSynonyms() {
        val contacts = listOf(
            ContactItem("1", "Amma (Mom / அம்மா)", listOf(ContactPhoneNumber("+919876543210", "Mobile", "+919876543210"))),
            ContactItem("2", "Arun Kumar (அருண்)", listOf(ContactPhoneNumber("+919444156789", "Mobile", "+919444156789"))),
            ContactItem("3", "Ramesh (ரமேஷ்)", listOf(ContactPhoneNumber("+919789012345", "Mobile", "+919789012345")))
        )

        // Query with Tamil dative suffix "-வுக்கு"
        val ammaMatches = ContactMatcher.findMatches("அம்மாவுக்கு", contacts)
        assertTrue(ammaMatches.isNotEmpty())
        assertEquals("Amma (Mom / அம்மா)", ammaMatches.first().contact.displayName)

        // Query with Tamil dative suffix "-க்கு"
        val rameshMatches = ContactMatcher.findMatches("ரமேஷுக்கு", contacts)
        assertTrue(rameshMatches.isNotEmpty())
        assertEquals("Ramesh (ரமேஷ்)", rameshMatches.first().contact.displayName)

        // Query with English name
        val arunMatches = ContactMatcher.findMatches("Arun", contacts)
        assertTrue(arunMatches.isNotEmpty())
        assertEquals("Arun Kumar (அருண்)", arunMatches.first().contact.displayName)
    }

    @Test
    fun testCallManagerEmergencyNumberProtection() {
        val settings = WakeWordSettings.getInstance(context)
        settings.setDirectCallingEnabled(false)

        // 911 must be blocked from automated call
        val blockedResult = CallManager.placeCall(context, "911")
        assertTrue(blockedResult is CallResult.Blocked)

        // 112 must be blocked
        val blocked112 = CallManager.placeCall(context, "112")
        assertTrue(blocked112 is CallResult.Blocked)

        // Standard number should open DIAL intent
        CallManager.resetDebounce()
        val successResult = CallManager.placeCall(context, "+91 98765 43210")
        assertTrue(successResult is CallResult.Success)
        assertEquals("ACTION_DIAL", (successResult as CallResult.Success).dialMethod)
    }

    @Test
    fun testWakeWordSettings() {
        val settings = WakeWordSettings.getInstance(context)
        settings.setWakeWordEnabled(true)
        assertTrue(settings.isWakeWordEnabled.value)

        settings.setSensitivity(0.75f)
        assertEquals(0.75f, settings.sensitivity.value, 0.01f)

        settings.setPlayChimeSound(false)
        assertFalse(settings.playChimeSound.value)

        settings.setDirectCallingEnabled(true)
        assertTrue(settings.directCallingEnabled.value)
    }

    @Test
    fun testWakeWordEngineSimulation() {
        val engine = WakeWordEngine(context)
        assertEquals(WakeWordEngineStatus.STOPPED, engine.status.value)

        var triggered = false
        engine.simulateDetection {
            triggered = true
        }

        // Test simulating detection with specific wake words
        var detectedWord = ""
        engine.simulateDetection("Hey Jarvis") { word ->
            detectedWord = word
        }
        assertEquals("Hey Jarvis", detectedWord)
        assertEquals("Hey Jarvis", engine.lastTriggeredWakeWord.value)

        engine.simulateDetection("Hey Siri") { word ->
            detectedWord = word
        }
        assertEquals("Hey Siri", detectedWord)

        engine.simulateDetection("Hey Tamil") { word ->
            detectedWord = word
        }
        assertEquals("Hey Tamil", detectedWord)

        engine.stopListening()
        assertEquals(WakeWordEngineStatus.STOPPED, engine.status.value)
    }

    @Test
    fun testWakeWordOptionSwitching() {
        val settings = WakeWordSettings.getInstance(context)
        settings.setSelectedWakeWord(WakeWordOption.HEY_JARVIS)
        assertEquals(WakeWordOption.HEY_JARVIS, settings.selectedWakeWord.value)

        settings.setSelectedWakeWord(WakeWordOption.HEY_SIRI)
        assertEquals(WakeWordOption.HEY_SIRI, settings.selectedWakeWord.value)

        settings.setSelectedWakeWord(WakeWordOption.HEY_TAMIL)
        assertEquals(WakeWordOption.HEY_TAMIL, settings.selectedWakeWord.value)

        settings.setSelectedWakeWord(WakeWordOption.ALL)
        assertEquals(WakeWordOption.ALL, settings.selectedWakeWord.value)
    }

    @Test
    fun testDeviceDutyManagerWakeWords() {
        // Hey Jarvis / hey jarvise
        val jarvisResult = DeviceDutyManager.processDutyCommand(context, "hey jarvise", "EN")
        assertTrue(jarvisResult is DutyResult.Success)
        assertEquals(ActionType.HEY_JARVIS, (jarvisResult as DutyResult.Success).actionType)
        assertTrue(jarvisResult.message.contains("Jarvis"))

        // Hey Siri
        val siriResult = DeviceDutyManager.processDutyCommand(context, "hey siri", "EN")
        assertTrue(siriResult is DutyResult.Success)
        assertEquals(ActionType.HEY_SIRI, (siriResult as DutyResult.Success).actionType)

        // HEY TAMIL
        val tamilResult = DeviceDutyManager.processDutyCommand(context, "HEY TAMIL", "TA")
        assertTrue(tamilResult is DutyResult.Success)
        assertEquals(ActionType.HEY_TAMIL, (tamilResult as DutyResult.Success).actionType)

        // Wake word with duty subcommand passthrough
        val torchDuty = DeviceDutyManager.processDutyCommand(context, "Hey Jarvis, turn on torch", "EN")
        assertTrue(torchDuty is DutyResult.Success)
        assertEquals(ActionType.TORCH_ON, (torchDuty as DutyResult.Success).actionType)
    }

    @Test
    fun testWakeWordEnginePauseAndResume() {
        val engine = WakeWordEngine(context)
        engine.pauseListening()
        assertTrue(engine.isPaused)
        assertEquals(WakeWordEngineStatus.PAUSED, engine.status.value)

        engine.resumeListening()
        assertFalse(engine.isPaused)
    }

    @Test
    fun testGlobalWakeWordActivationFlow() {
        val app = context.applicationContext as android.app.Application
        val viewModel = com.example.ui.ChatViewModel(app)

        viewModel.onGlobalWakeWordActivated("Hey Jarvis")
        assertTrue(viewModel.isGlobalWakeListening.value)
        assertEquals("Hi Venkat, I am listening...", viewModel.globalWakeStatusText.value)

        // Verify duplicate activation within 3 seconds is prevented
        viewModel.onGlobalWakeWordActivated("Hey Jarvis")
        assertTrue(viewModel.isGlobalWakeListening.value)

        viewModel.cancelGlobalWakeListening()
        assertFalse(viewModel.isGlobalWakeListening.value)
    }

    @Test
    fun testGirlfriendCompanionEngineLoveAndGreetings() {
        // English love & greetings
        val loveResultEn = com.example.data.companion.GirlfriendCompanionEngine.generateResponse(context, "I love you", "EN")
        assertNotNull(loveResultEn)
        assertEquals(com.example.data.companion.CompanionIntent.LOVE, loveResultEn!!.intent)
        assertTrue(loveResultEn.text.contains("Venkat"))

        // Tamil greetings
        val morningTa = com.example.data.companion.GirlfriendCompanionEngine.generateResponse(context, "காலை வணக்கம்", "TA")
        assertNotNull(morningTa)
        assertEquals(com.example.data.companion.CompanionIntent.GOOD_MORNING, morningTa!!.intent)
        assertTrue(morningTa.text.contains("Venkat"))

        // Tanglish did you eat
        val eatTanglish = com.example.data.companion.GirlfriendCompanionEngine.generateResponse(context, "sapdiya da venkat", "AUTO")
        assertNotNull(eatTanglish)
        assertEquals(com.example.data.companion.CompanionIntent.DID_YOU_EAT, eatTanglish!!.intent)

        // Missing you
        val missYouResult = com.example.data.companion.GirlfriendCompanionEngine.generateResponse(context, "I miss you", "EN")
        assertNotNull(missYouResult)
        assertEquals(com.example.data.companion.CompanionIntent.MISS_YOU, missYouResult!!.intent)

        // Do you miss me
        val doYouMissMe = com.example.data.companion.GirlfriendCompanionEngine.generateResponse(context, "Do you miss me?", "EN")
        assertNotNull(doYouMissMe)
        assertEquals(com.example.data.companion.CompanionIntent.DO_YOU_MISS_ME, doYouMissMe!!.intent)
    }

    @Test
    fun testGirlfriendCompanionEngineRoutingSeparation() {
        // Supported offline companion queries MUST return true
        assertTrue(com.example.data.companion.GirlfriendCompanionEngine.isSupportedOfflineIntent("I love you"))
        assertTrue(com.example.data.companion.GirlfriendCompanionEngine.isSupportedOfflineIntent("Good morning"))
        assertTrue(com.example.data.companion.GirlfriendCompanionEngine.isSupportedOfflineIntent("Did you eat?"))
        assertTrue(com.example.data.companion.GirlfriendCompanionEngine.isSupportedOfflineIntent("how are you"))
        assertTrue(com.example.data.companion.GirlfriendCompanionEngine.isSupportedOfflineIntent("I am sad"))
        assertTrue(com.example.data.companion.GirlfriendCompanionEngine.isSupportedOfflineIntent("I am happy"))
        assertTrue(com.example.data.companion.GirlfriendCompanionEngine.isSupportedOfflineIntent("I am bored"))
        assertTrue(com.example.data.companion.GirlfriendCompanionEngine.isSupportedOfflineIntent("Thank you"))
        assertTrue(com.example.data.companion.GirlfriendCompanionEngine.isSupportedOfflineIntent("Sorry"))
        assertTrue(com.example.data.companion.GirlfriendCompanionEngine.isSupportedOfflineIntent("Take care"))
        assertTrue(com.example.data.companion.GirlfriendCompanionEngine.isSupportedOfflineIntent("See you"))

        // Advanced educational/knowledge queries MUST NOT be intercepted by the offline companion
        assertFalse(com.example.data.companion.GirlfriendCompanionEngine.isSupportedOfflineIntent("What is Artificial Intelligence?"))
        assertFalse(com.example.data.companion.GirlfriendCompanionEngine.isSupportedOfflineIntent("Explain quantum physics"))
        assertFalse(com.example.data.companion.GirlfriendCompanionEngine.isSupportedOfflineIntent("Solve this mathematical problem: 2x + 5 = 15"))
        assertFalse(com.example.data.companion.GirlfriendCompanionEngine.isSupportedOfflineIntent("Explain Android development"))
        assertFalse(com.example.data.companion.GirlfriendCompanionEngine.isSupportedOfflineIntent("Tell me today's news"))
    }

    @Test
    fun testGirlfriendCompanionEngineNonRepeating() {
        com.example.data.companion.GirlfriendCompanionEngine.resetContext()
        val first = com.example.data.companion.GirlfriendCompanionEngine.generateResponse(context, "I love you", "EN")
        val second = com.example.data.companion.GirlfriendCompanionEngine.generateResponse(context, "I love you", "EN")
        assertNotNull(first)
        assertNotNull(second)
        // With rotation index, the successive calls provide dynamic variations
        assertFalse(first!!.text.isEmpty())
        assertFalse(second!!.text.isEmpty())
    }

    @Test
    fun testStrictWakeWordMatchingAndFalseActivationRejection() {
        // 1. False activations that MUST be rejected
        val aathiKitta = com.example.wakeword.StrictWakeWordVerifier.verify("Aathi Kitta")
        assertFalse("Aathi Kitta must be rejected", aathiKitta.isMatch)

        val openYoutubeAlone = com.example.wakeword.StrictWakeWordVerifier.verify("Open YouTube")
        assertFalse("Open YouTube alone must be rejected", openYoutubeAlone.isMatch)

        val unrelatedTamil = com.example.wakeword.StrictWakeWordVerifier.verify("நான் கடைக்கு போகிறேன்")
        assertFalse("Unrelated Tamil sentence must be rejected", unrelatedTamil.isMatch)

        val partialJarvis = com.example.wakeword.StrictWakeWordVerifier.verify("Jarvis")
        assertFalse("Partial wake word 'Jarvis' without 'Hey' must be rejected", partialJarvis.isMatch)

        val partialKitty = com.example.wakeword.StrictWakeWordVerifier.verify("Kitty")
        assertFalse("Partial wake word 'Kitty' without 'Hi' must be rejected", partialKitty.isMatch)

        val partialSiri = com.example.wakeword.StrictWakeWordVerifier.verify("Siri")
        assertFalse("Partial wake word 'Siri' without 'Hey' must be rejected", partialSiri.isMatch)

        // 2. Genuine registered wake words that MUST be activated
        val jarvis = com.example.wakeword.StrictWakeWordVerifier.verify("Hey Jarvis")
        assertTrue(jarvis.isMatch)
        assertEquals("Hey Jarvis", jarvis.matchedWakeWord)

        val siri = com.example.wakeword.StrictWakeWordVerifier.verify("Hey Siri")
        assertTrue(siri.isMatch)
        assertEquals("Hey Siri", siri.matchedWakeWord)

        val tamil = com.example.wakeword.StrictWakeWordVerifier.verify("Hey Tamil")
        assertTrue(tamil.isMatch)
        assertEquals("Hey Tamil", tamil.matchedWakeWord)

        val kitty = com.example.wakeword.StrictWakeWordVerifier.verify("Hi Kitty")
        assertTrue(kitty.isMatch)
        assertEquals("Hi Kitty", kitty.matchedWakeWord)

        // 3. Wake word followed by command
        val jarvisCommand = com.example.wakeword.StrictWakeWordVerifier.verify("Hey Jarvis, open YouTube")
        assertTrue(jarvisCommand.isMatch)
        assertEquals("Hey Jarvis", jarvisCommand.matchedWakeWord)
        assertEquals("open youtube", jarvisCommand.remainderCommand.trim())
    }

    @Test
    fun testAlarmDutyCommand() {
        val alarmResult = DeviceDutyManager.processDutyCommand(context, "Set an alarm for 6 AM", "EN")
        assertTrue(alarmResult is DutyResult.Success)
        val success = alarmResult as DutyResult.Success
        assertEquals(ActionType.SET_ALARM, success.actionType)
        assertTrue(success.message.contains("6:00 AM"))

        // Wake me up at 7:30 AM
        val wakeUp = DeviceDutyManager.processDutyCommand(context, "Wake me up at 7:30 AM", "EN")
        assertTrue(wakeUp is DutyResult.Success)
        assertEquals(ActionType.SET_ALARM, (wakeUp as DutyResult.Success).actionType)

        // Tamil alarm
        val tamilAlarm = DeviceDutyManager.processDutyCommand(context, "காலை 6 மணிக்கு அலாரம் வை", "TA")
        assertTrue(tamilAlarm is DutyResult.Success)
        assertEquals(ActionType.SET_ALARM, (tamilAlarm as DutyResult.Success).actionType)
    }

    @Test
    fun testPersonalVoiceAuthenticationAndSpeakerVerification() {
        val manager = com.example.voiceauth.VoiceProfileManager.getInstance(context)
        manager.deleteProfile()

        // Create synthetic speech audio samples representing Speaker A (Venkat)
        val speakerASamples = ShortArray(1600) { i ->
            // Fundamental 150 Hz voice tone with harmonics
            ((kotlin.math.sin(2.0 * kotlin.math.PI * 150.0 * i / 16000.0) * 12000.0) +
                    (kotlin.math.sin(2.0 * kotlin.math.PI * 300.0 * i / 16000.0) * 4000.0)).toInt().toShort()
        }

        // Create synthetic speech audio samples representing Speaker B (Impostor)
        val speakerBSamples = ShortArray(1600) { i ->
            // Fundamental 280 Hz voice tone (different acoustic profile)
            ((kotlin.math.sin(2.0 * kotlin.math.PI * 280.0 * i / 16000.0) * 10000.0) +
                    (kotlin.math.sin(2.0 * kotlin.math.PI * 560.0 * i / 16000.0) * 5000.0)).toInt().toShort()
        }

        // 1. Fallback test when Auth is OFF -> allows activation
        manager.setAuthEnabled(false)
        val fallbackResult = manager.verifySpeaker(speakerASamples)
        assertTrue("When Personal Voice Auth is OFF, verification must allow activation", fallbackResult.isMatch)

        // 2. Register Speaker A
        manager.startRegistration()
        assertTrue(manager.recordSample(speakerASamples))
        assertTrue(manager.recordSample(speakerASamples))
        assertTrue(manager.finalizeRegistration("Venkat"))
        assertTrue("Profile must be marked as registered", manager.isRegistered.value)

        // 3. Enable Personal Voice Authentication
        manager.setAuthEnabled(true)
        manager.setAccuracyThreshold(0.70f)

        // Speaker A speaks -> MATCH
        val matchResult = manager.verifySpeaker(speakerASamples)
        assertTrue("Registered voice must match and activate", matchResult.isMatch)
        assertTrue(matchResult.similarity >= 0.70f)

        // Speaker B (different person) speaks -> REJECT
        val impostorResult = manager.verifySpeaker(speakerBSamples)
        assertFalse("Different person's voice must be rejected", impostorResult.isMatch)

        // Clean up
        manager.deleteProfile()
        assertFalse(manager.isRegistered.value)
    }

    @Test
    fun testSmartReminderSystemNaturalLanguageAndDatabase() = kotlinx.coroutines.test.runTest {
        // 1. Natural Language Parser Tests
        val parsed1 = com.example.reminder.NaturalReminderParser.parse("Remind me to study at 6 PM")
        assertTrue("Must be identified as reminder command", parsed1.isReminderCommand)
        assertFalse("Must not need clarification", parsed1.needsClarification)
        assertNotNull("Target time must be parsed", parsed1.targetTimeMillis)
        assertEquals("Study", parsed1.title)

        val parsedTomorrow = com.example.reminder.NaturalReminderParser.parse("Remind me tomorrow morning")
        assertTrue(parsedTomorrow.isReminderCommand)
        assertNotNull(parsedTomorrow.targetTimeMillis)

        val parsedRepeat = com.example.reminder.NaturalReminderParser.parse("Remind me every Sunday")
        assertTrue(parsedRepeat.isReminderCommand)
        assertEquals(com.example.reminder.RepeatFrequency.WEEKLY, parsedRepeat.repeatFrequency)

        val parsedTamil = com.example.reminder.NaturalReminderParser.parse("நாளை காலை 7 மணிக்கு மாத்திரை சாப்பிட நினைவூட்டு")
        assertTrue("Tamil reminder must be identified", parsedTamil.isReminderCommand)
        assertNotNull(parsedTamil.targetTimeMillis)

        val parsedVague = com.example.reminder.NaturalReminderParser.parse("Remind me")
        assertTrue(parsedVague.isReminderCommand)
        assertTrue("Vague reminder must ask for clarification", parsedVague.needsClarification)

        // 2. Repository Database Persistence Test
        val repo = com.example.reminder.ReminderRepository(context)
        val testReminder = com.example.reminder.ReminderEntity(
            title = "Test Homework",
            scheduledTimeMillis = System.currentTimeMillis() + 3600000L,
            repeatFrequency = com.example.reminder.RepeatFrequency.DAILY.name,
            isEnabled = true,
            isCompleted = false
        )
        repo.createReminder(testReminder)

        // Verify duty manager integration
        val dutyResult = DeviceDutyManager.processDutyCommand(context, "Remind me to call Mom at 8 PM", "EN")
        assertTrue("Reminder duty must succeed", dutyResult is DutyResult.Success)
        assertEquals(ActionType.SET_REMINDER, (dutyResult as DutyResult.Success).actionType)

        // Clean up
        repo.deleteReminder(testReminder.id)
    }
}


