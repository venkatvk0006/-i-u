package com.example.data.companion

import android.content.Context
import android.graphics.Bitmap
import com.example.data.ai.AiRepository
import com.example.data.ai.OnDeviceAiEngine
import com.example.data.model.ChatMessageEntity
import com.example.util.DeviceDutyManager
import com.example.util.DutyResult
import com.example.util.NetworkUtil
import com.example.util.TextToSpeechHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

sealed class RouterSource {
    data object OfflineCompanion : RouterSource()
    data object OfflineDuty : RouterSource()
    data object OfflineOnDevice : RouterSource()
    data object OnlineGemini : RouterSource()
    data object OfflineFallbackNotice : RouterSource()
}

data class RouteResolution(
    val source: RouterSource,
    val initialText: String? = null
)

/**
 * SMART HYBRID RESPONSE ROUTER
 * Optimized for Redmi Note 11 (Snapdragon 680, 4GB RAM).
 *
 * Routing Rules:
 * 1. Device Duties (torch, wifi, apps, volume, camera) -> Executed locally.
 * 2. Girlfriend Mode (casual/caring conversations) -> Answered locally 100% offline (even if internet is online).
 * 3. Advanced / Reasoning / Complex Questions:
 *    - If Internet is available -> Answered via Online Gemini API.
 *    - If Internet is unavailable -> Transparently explains that internet is required without fake simulations.
 */
object HybridResponseRouter {

    fun routeAndStream(
        context: Context,
        rawPrompt: String,
        bitmap: Bitmap? = null,
        history: List<ChatMessageEntity> = emptyList(),
        languagePreference: String = "AUTO",
        aiRepository: AiRepository,
        ttsHelper: TextToSpeechHelper? = null,
        isGirlfriendModeEnabled: Boolean = true,
        forceOnDeviceOnly: Boolean = false
    ): Flow<String> = flow {
        val prompt = rawPrompt.trim()

        // 1. Device Control Duties (Torch, Camera, Gallery, Volume, Apps, Calling, etc.)
        val dutyResult = DeviceDutyManager.processDutyCommand(context, prompt, languagePreference)
        if (dutyResult is DutyResult.Success) {
            val msg = when (languagePreference) {
                "TA" -> dutyResult.tamilMessage
                "HI" -> dutyResult.hindiMessage
                else -> dutyResult.message
            }
            emit("⚡ **Action Executed:** $msg")
            return@flow
        }

        // 2. Smart Hybrid Girlfriend Mode (Offline personal & caring conversations)
        if (isGirlfriendModeEnabled) {
            val companionResult = GirlfriendCompanionEngine.generateResponse(context, prompt, languagePreference)
            if (companionResult != null) {
                // Stream the offline response with smooth natural cadence
                val words = companionResult.text.split(" ")
                for (i in words.indices) {
                    val chunk = if (i == words.lastIndex) words[i] else words[i] + " "
                    emit(chunk)
                    delay(16L)
                }
                return@flow
            }
        }

        // 3. General On-Device Basic System Duties (Memory notes, device specs, calculation)
        if (isBasicOnDeviceCommand(prompt) || forceOnDeviceOnly) {
            OnDeviceAiEngine.streamOnDeviceResponse(
                context = context,
                prompt = prompt,
                currentLang = languagePreference,
                ttsHelper = ttsHelper
            ).collect { chunk ->
                emit(chunk)
            }
            return@flow
        }

        // 4. Advanced Intelligence / General Knowledge / Reasoning / Coding / Creative Content
        val isOnline = NetworkUtil.isInternetAvailable(context)

        if (isOnline) {
            // Online Gemini mode
            aiRepository.streamChat(
                prompt = prompt,
                bitmap = bitmap,
                history = history,
                languagePreference = languagePreference
            ).collect { chunk ->
                emit(chunk)
            }
        } else {
            // Internet is unavailable: Honestly and sweetly explain that internet is required
            val isTamil = prompt.any { it in '\u0B80'..'\u0BFF' } || languagePreference == "TA"
            val isTanglish = isTanglish(prompt.lowercase())

            val notice = when {
                isTamil -> """
🌐 **இணைய இணைப்பு தேவைப்படுகிறது**

மன்னிக்கவும் Venkat, இந்தக் கேள்விக்கு முழுமையாக விளக்கம் அளிக்க எனக்கு இணைய இணைப்பு (Internet) தேவைப்படுகிறது.

தயவுசெய்து உங்கள் சாதனத்தில் Wi-Fi அல்லது மொபைல் டேட்டாவை ஆன் செய்துவிட்டு மீண்டும் கேளுங்கள், நான் உடனடியாக பதிலளிக்கிறேன் ❤️
""".trimIndent()

                isTanglish -> """
🌐 **Internet Connection Thevai**

Venkat da, indha complex vishayathuku explain panna enaku internet connection thevai padudhu!

Wi-Fi illa mobile data on pannitu marubadiyum kelunga, naan udane explain panren chellam ❤️
""".trimIndent()

                else -> """
🌐 **Internet Connection Required**

I need an active internet connection to search and answer advanced questions like that for you, Venkat! 

Please connect to Wi-Fi or turn on mobile data, and ask me again. I'll be ready to give you a complete answer! ❤️
""".trimIndent()
            }

            emit(notice)
        }
    }

    private fun isBasicOnDeviceCommand(rawPrompt: String): Boolean {
        val lower = rawPrompt.lowercase().trim()
        return lower.startsWith("remember this") ||
                lower.startsWith("remember:") ||
                lower.contains("what do you remember") ||
                lower.contains("show memory") ||
                lower.contains("start on-device ai") ||
                lower.contains("device information") ||
                lower.contains("device info") ||
                lower.contains("battery status") ||
                lower.contains("speak faster") ||
                lower.contains("speak slowly") ||
                lower.contains("tamil mode") ||
                lower.contains("english mode")
    }

    private fun isTanglish(text: String): Boolean {
        val keywords = listOf("da", "di", "enna", "panra", "sapdiya", "kooda", "venkat", "romba", "solren", "thevai")
        return keywords.any { text.contains(it) }
    }
}
