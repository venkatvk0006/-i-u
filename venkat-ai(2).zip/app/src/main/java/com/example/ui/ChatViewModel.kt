package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.AiRepository
import com.example.data.local.VenkatAiDatabase
import com.example.data.model.ChatMessageEntity
import com.example.data.model.ConversationEntity
import com.example.ui.theme.ThemeMode
import com.example.util.ImageUtil
import com.example.util.TextToSpeechHelper
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

private const val TAG = "ChatViewModel"

sealed interface AiChatState {
    data object Idle : AiChatState
    data object Thinking : AiChatState
    data class Streaming(val accumulatedText: String) : AiChatState
    data class Error(val errorMessage: String) : AiChatState
}

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val db = VenkatAiDatabase.getDatabase(application)
    private val dao = db.chatDao()
    private val aiRepository = AiRepository()
    val ttsHelper = TextToSpeechHelper(application)

    // Conversations
    val conversations: StateFlow<List<ConversationEntity>> = dao.getAllConversations()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    private val _currentConversation = MutableStateFlow<ConversationEntity?>(null)
    val currentConversation: StateFlow<ConversationEntity?> = _currentConversation.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessageEntity>>(emptyList())
    val messages: StateFlow<List<ChatMessageEntity>> = _messages.asStateFlow()

    // Input state
    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    private val _selectedImageUri = MutableStateFlow<Uri?>(null)
    val selectedImageUri: StateFlow<Uri?> = _selectedImageUri.asStateFlow()

    private val _selectedImageBitmap = MutableStateFlow<Bitmap?>(null)

    // AI Status
    private val _aiState = MutableStateFlow<AiChatState>(AiChatState.Idle)
    val aiState: StateFlow<AiChatState> = _aiState.asStateFlow()

    // Settings
    private val _languageMode = MutableStateFlow("AUTO") // AUTO, EN, TA
    val languageMode: StateFlow<String> = _languageMode.asStateFlow()

    private val _themeMode = MutableStateFlow(ThemeMode.SYSTEM)
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    // Full On-Device AI Mode (Enabled by default for instant offline execution)
    private val _useOnDeviceAi = MutableStateFlow(true)
    val useOnDeviceAi: StateFlow<Boolean> = _useOnDeviceAi.asStateFlow()

    // Smart Hybrid Girlfriend Companion Mode (Sweet Indian female companion personality)
    private val _isGirlfriendMode = MutableStateFlow(true)
    val isGirlfriendMode: StateFlow<Boolean> = _isGirlfriendMode.asStateFlow()

    fun setGirlfriendMode(enabled: Boolean) {
        _isGirlfriendMode.value = enabled
    }

    // Global Wake Word Activation & Voice Command State
    val speechRecognizer = com.example.calling.OfflineSpeechRecognizer(application)

    private val _isGlobalWakeListening = MutableStateFlow(false)
    val isGlobalWakeListening: StateFlow<Boolean> = _isGlobalWakeListening.asStateFlow()

    private val _globalWakeStatusText = MutableStateFlow<String?>(null)
    val globalWakeStatusText: StateFlow<String?> = _globalWakeStatusText.asStateFlow()

    // Hands-Free Conversation Mode (Consecutive voice commands without re-saying wake word)
    private val _isConversationMode = MutableStateFlow(true)
    val isConversationMode: StateFlow<Boolean> = _isConversationMode.asStateFlow()

    private val _isHandsFreeActive = MutableStateFlow(false)
    val isHandsFreeActive: StateFlow<Boolean> = _isHandsFreeActive.asStateFlow()

    private val _livePartialSpeechText = MutableStateFlow("")
    val livePartialSpeechText: StateFlow<String> = _livePartialSpeechText.asStateFlow()

    private val _vadSilenceTimeoutMs = MutableStateFlow(1500L)
    val vadSilenceTimeoutMs: StateFlow<Long> = _vadSilenceTimeoutMs.asStateFlow()

    var onVoiceCommandExecuted: ((String) -> Unit)? = null

    fun setConversationMode(enabled: Boolean) {
        _isConversationMode.value = enabled
    }

    fun setVadSilenceTimeout(timeoutMs: Long) {
        _vadSilenceTimeoutMs.value = timeoutMs
        speechRecognizer.silenceTimeoutMs = timeoutMs
    }

    private var lastWakeWordActivationTime = 0L

    private var activeGenerationJob: Job? = null
    private var messageCollectionJob: Job? = null

    init {
        // Observe conversations and auto-select latest or create first
        viewModelScope.launch {
            conversations.collectLatest { list ->
                if (_currentConversation.value == null && list.isNotEmpty()) {
                    selectConversation(list.first())
                }
            }
        }
    }

    fun onInputTextChanged(text: String) {
        _inputText.value = text
    }

    fun onImageSelected(uri: Uri?) {
        _selectedImageUri.value = uri
        if (uri != null) {
            viewModelScope.launch {
                val bitmap = ImageUtil.loadScaledBitmap(getApplication(), uri)
                _selectedImageBitmap.value = bitmap
            }
        } else {
            _selectedImageBitmap.value = null
        }
    }

    fun clearSelectedImage() {
        _selectedImageUri.value = null
        _selectedImageBitmap.value = null
    }

    fun setLanguageMode(mode: String) {
        _languageMode.value = mode
    }

    fun setThemeMode(mode: ThemeMode) {
        _themeMode.value = mode
    }

    fun setUseOnDeviceAi(value: Boolean) {
        _useOnDeviceAi.value = value
    }

    fun createNewChat() {
        activeGenerationJob?.cancel()
        _aiState.value = AiChatState.Idle
        _inputText.value = ""
        clearSelectedImage()
        _currentConversation.value = null
        _messages.value = emptyList()
    }

    fun selectConversation(conversation: ConversationEntity) {
        if (_currentConversation.value?.id == conversation.id) return
        activeGenerationJob?.cancel()
        _aiState.value = AiChatState.Idle
        _currentConversation.value = conversation
        clearSelectedImage()
        _inputText.value = ""

        messageCollectionJob?.cancel()
        messageCollectionJob = viewModelScope.launch {
            dao.getMessagesForConversation(conversation.id).collectLatest { msgs ->
                _messages.value = msgs
            }
        }
    }

    fun deleteConversation(id: String) {
        viewModelScope.launch {
            dao.deleteConversationById(id)
            if (_currentConversation.value?.id == id) {
                createNewChat()
            }
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            dao.deleteAllConversations()
            createNewChat()
        }
    }

    /**
     * Triggered when ANY registered wake word ("Hi Kitty", "Hey Jarvis", "Hey Siri", "Hey Tamil") is detected.
     * 1. Activates hands-free session and prevents mic contention.
     * 2. Speaks confirmation: "Hi Venkat, I am listening."
     * 3. Automatically activates microphone with Intelligent VAD.
     */
    fun onGlobalWakeWordActivated(wakeWordName: String) {
        val now = System.currentTimeMillis()
        // Prevent repeated activations when the same wake word is spoken multiple times
        if (now - lastWakeWordActivationTime < 3000L) {
            Log.d(TAG, "Prevented repeated wake word activation for '$wakeWordName'")
            return
        }
        lastWakeWordActivationTime = now

        // Stop any running generation/speech
        activeGenerationJob?.cancel()
        ttsHelper.stop()

        _isHandsFreeActive.value = true
        _isGlobalWakeListening.value = true
        _livePartialSpeechText.value = ""
        _globalWakeStatusText.value = "Hi Venkat, I am listening..."

        // Mandatory exact verbal response: "Hi Venkat, I am listening."
        ttsHelper.speak("Hi Venkat, I am listening.", "global_wake_prompt") {
            // Automatically activate voice recognition after speaking finishes
            viewModelScope.launch(kotlinx.coroutines.Dispatchers.Main) {
                startVoiceRecognitionForCommand(isFollowUp = false)
            }
        }
    }

    private fun startVoiceRecognitionForCommand(isFollowUp: Boolean) {
        if (!_isHandsFreeActive.value) return

        _isGlobalWakeListening.value = true
        _globalWakeStatusText.value = if (isFollowUp) {
            "Listening for next command... (or say 'exit')"
        } else {
            "Listening for your command..."
        }
        _livePartialSpeechText.value = ""

        val timeout = if (isFollowUp) 6000L else _vadSilenceTimeoutMs.value

        speechRecognizer.startListening(
            language = _languageMode.value,
            timeoutMs = _vadSilenceTimeoutMs.value,
            onPartialResult = { partial ->
                _livePartialSpeechText.value = partial
                _globalWakeStatusText.value = "🗣️ \"$partial\""
            },
            onResult = { spokenText ->
                _livePartialSpeechText.value = ""
                val cleanCommand = spokenText.trim()

                // Check for conversation termination commands
                if (isExitOrStopCommand(cleanCommand)) {
                    _globalWakeStatusText.value = "Goodbye Venkat!"
                    val farewell = if (_languageMode.value == "TA") {
                        "சரி Venkat, அப்புறம் பேசலாம்! எப்போது வேண்டுமானாலும் கூப்பிடுங்கள்."
                    } else {
                        "Goodbye Venkat! Call me anytime."
                    }
                    ttsHelper.speak(farewell, "farewell") {
                        exitHandsFreeSession()
                    }
                    return@startListening
                }

                if (cleanCommand.isNotBlank()) {
                    _globalWakeStatusText.value = "Processing: \"$cleanCommand\"..."
                    dispatchVoiceCommand(cleanCommand)
                } else {
                    if (isFollowUp) {
                        // Natural conversation pause expired
                        exitHandsFreeSession()
                    } else {
                        // Spoken error feedback when recognition hears nothing
                        val errText = if (_languageMode.value == "TA") {
                            "மன்னிக்கவும் Venkat, நீங்கள் பேசியது எனக்கு சரியாக கேட்கவில்லை. எப்போது வேண்டுமானாலும் 'Hey Jarvis' என்று கூப்பிடுங்கள்."
                        } else {
                            "Sorry Venkat, I didn't catch that. Say 'Hey Jarvis' whenever you need me."
                        }
                        ttsHelper.speak(errText, "no_speech_prompt") {
                            exitHandsFreeSession()
                        }
                    }
                }
            },
            onError = { errorMsg ->
                Log.w(TAG, "Command voice recognition error: $errorMsg (isFollowUp=$isFollowUp)")
                _livePartialSpeechText.value = ""
                if (isFollowUp) {
                    exitHandsFreeSession()
                } else {
                    val errText = if (_languageMode.value == "TA") {
                        "மன்னிக்கவும் Venkat, நீங்கள் பேசியது கேட்கவில்லை. தயாரானதும் 'Hey Jarvis' என்று சொல்லுங்கள்."
                    } else {
                        "Sorry Venkat, I couldn't hear that clearly. Say 'Hey Jarvis' when you're ready."
                    }
                    ttsHelper.speak(errText, "speech_error_prompt") {
                        exitHandsFreeSession()
                    }
                }
            }
        )
    }

    private fun isExitOrStopCommand(command: String): Boolean {
        val lower = command.lowercase().trim()
        val exitWords = listOf("stop", "exit", "quit", "bye", "goodbye", "shutdown", "போதும்", "நிறுத்து", "முடிக்கவும்", "போயிட்டு வரேன்")
        return exitWords.any { lower == it || lower.startsWith("$it ") || lower.endsWith(" $it") }
    }

    private fun dispatchVoiceCommand(command: String) {
        val customDispatcher = onVoiceCommandExecuted
        if (customDispatcher != null) {
            customDispatcher(command)
        } else {
            sendMessage(command)
        }
    }

    fun startFollowUpListening() {
        if (!_isHandsFreeActive.value || !_isConversationMode.value) {
            exitHandsFreeSession()
            return
        }
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.Main) {
            startVoiceRecognitionForCommand(isFollowUp = true)
        }
    }

    fun exitHandsFreeSession() {
        _isHandsFreeActive.value = false
        _isGlobalWakeListening.value = false
        _globalWakeStatusText.value = null
        _livePartialSpeechText.value = ""
        speechRecognizer.stopListening()
        com.example.wakeword.WakeWordService.resumeListening(getApplication())
    }

    fun cancelGlobalWakeListening() {
        exitHandsFreeSession()
    }

    fun sendMessage(promptOverride: String? = null) {
        val prompt = (promptOverride ?: _inputText.value).trim()
        val bitmap = _selectedImageBitmap.value
        val imageUri = _selectedImageUri.value

        if (prompt.isEmpty() && bitmap == null) return
        if (_aiState.value is AiChatState.Thinking || _aiState.value is AiChatState.Streaming) return

        // Capture existing past messages BEFORE adding new user message
        val pastHistory = _messages.value.toList()

        // Clear input field and image
        _inputText.value = ""
        clearSelectedImage()

        activeGenerationJob = viewModelScope.launch {
            try {
                // Ensure active conversation
                var conversation = _currentConversation.value
                val isNewConversation = conversation == null

                if (conversation == null) {
                    val newConv = ConversationEntity(
                        title = prompt.take(30).ifEmpty { "Assistant Action" },
                        languageMode = _languageMode.value
                    )
                    dao.insertConversation(newConv)
                    _currentConversation.value = newConv
                    conversation = newConv

                    // Bind message collection for new conversation
                    messageCollectionJob?.cancel()
                    messageCollectionJob = viewModelScope.launch {
                        dao.getMessagesForConversation(newConv.id).collectLatest { msgs ->
                            _messages.value = msgs
                        }
                    }
                } else {
                    // Update conversation timestamp
                    dao.updateConversation(conversation.copy(updatedAt = System.currentTimeMillis()))
                }

                // Save local image path if image attached
                var localImagePath: String? = null
                if (imageUri != null) {
                    localImagePath = ImageUtil.saveImageLocally(getApplication(), imageUri)
                }

                // Insert User message
                val userMessage = ChatMessageEntity(
                    conversationId = conversation.id,
                    role = "user",
                    content = prompt,
                    imageUri = localImagePath ?: imageUri?.toString()
                )
                dao.insertMessage(userMessage)

                // Set AI state to Thinking
                _aiState.value = AiChatState.Thinking

                val accumulated = StringBuilder()

                try {
                    com.example.data.companion.HybridResponseRouter.routeAndStream(
                        context = getApplication(),
                        rawPrompt = prompt,
                        bitmap = bitmap,
                        history = pastHistory,
                        languagePreference = _languageMode.value,
                        aiRepository = aiRepository,
                        ttsHelper = ttsHelper,
                        isGirlfriendModeEnabled = _isGirlfriendMode.value,
                        forceOnDeviceOnly = _useOnDeviceAi.value
                    ).collect { chunk ->
                        accumulated.append(chunk)
                        _aiState.value = AiChatState.Streaming(accumulated.toString())
                    }
                } catch (e: Exception) {
                    if (e is CancellationException && e !is TimeoutCancellationException) throw e
                    Log.w(TAG, "Hybrid routing stream failed, falling back to on-device engine", e)
                    if (accumulated.isEmpty()) {
                        com.example.data.ai.OnDeviceAiEngine.streamOnDeviceResponse(
                            context = getApplication(),
                            prompt = prompt,
                            currentLang = _languageMode.value,
                            ttsHelper = ttsHelper
                        ).collect { chunk ->
                            accumulated.append(chunk)
                            _aiState.value = AiChatState.Streaming(accumulated.toString())
                        }
                    } else {
                        throw e
                    }
                }

                val finalAiResponse = accumulated.toString().trim()
                if (finalAiResponse.isNotEmpty()) {
                    val aiMessage = ChatMessageEntity(
                        conversationId = conversation.id,
                        role = "model",
                        content = finalAiResponse
                    )
                    dao.insertMessage(aiMessage)
                    _aiState.value = AiChatState.Idle

                    // Speak the AI assistant response and resume or continue hands-free conversation
                    ttsHelper.speak(finalAiResponse, aiMessage.id) {
                        if (_isHandsFreeActive.value && _isConversationMode.value) {
                            startFollowUpListening()
                        } else {
                            exitHandsFreeSession()
                        }
                    }

                    // If it was the first turn, generate title
                    if (isNewConversation && prompt.isNotEmpty()) {
                        launch {
                            val smartTitle = if (_isGirlfriendMode.value && com.example.data.companion.GirlfriendCompanionEngine.isSupportedOfflineIntent(prompt)) {
                                prompt.take(28).replaceFirstChar { it.uppercase() }
                            } else if (_useOnDeviceAi.value) {
                                prompt.take(28).replaceFirstChar { it.uppercase() }
                            } else {
                                try {
                                    aiRepository.generateTitle(prompt)
                                } catch (e: Exception) {
                                    prompt.take(28).replaceFirstChar { it.uppercase() }
                                }
                            }
                            dao.updateConversation(conversation.copy(title = smartTitle))
                            _currentConversation.value = conversation.copy(title = smartTitle)
                        }
                    }
                } else {
                    _aiState.value = AiChatState.Error("VENKAT AI received an empty response. Please try again.")
                    exitHandsFreeSession()
                }

            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "AI streaming timed out", e)
                _aiState.value = AiChatState.Error("Generation timed out. Switched to on-device assistant mode.")
                exitHandsFreeSession()
            } catch (e: CancellationException) {
                // Cooperative cancellation re-throw
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Error generating response", e)
                val errorMessage = e.localizedMessage ?: "Failed to connect to VENKAT AI."
                _aiState.value = AiChatState.Error(errorMessage)
                exitHandsFreeSession()
            }
        }
    }

    fun stopGeneration() {
        activeGenerationJob?.cancel()
        val currentState = _aiState.value
        if (currentState is AiChatState.Streaming && currentState.accumulatedText.isNotBlank()) {
            val convId = _currentConversation.value?.id
            if (convId != null) {
                viewModelScope.launch {
                    val aiMessage = ChatMessageEntity(
                        conversationId = convId,
                        role = "model",
                        content = currentState.accumulatedText
                    )
                    dao.insertMessage(aiMessage)
                }
            }
        }
        _aiState.value = AiChatState.Idle
    }

    fun regenerateLastAnswer() {
        val conv = _currentConversation.value ?: return
        val currentMsgs = _messages.value
        if (currentMsgs.isEmpty()) return

        val lastUserMsg = currentMsgs.lastOrNull { it.role == "user" } ?: return
        val historyBeforeLastUser = currentMsgs.takeWhile { it.id != lastUserMsg.id }

        activeGenerationJob?.cancel()
        _aiState.value = AiChatState.Thinking

        activeGenerationJob = viewModelScope.launch {
            try {
                // Delete previous model response if it exists
                dao.deleteLastModelMessage(conv.id)

                val accumulated = StringBuilder()

                try {
                    com.example.data.companion.HybridResponseRouter.routeAndStream(
                        context = getApplication(),
                        rawPrompt = lastUserMsg.content,
                        bitmap = null,
                        history = historyBeforeLastUser,
                        languagePreference = _languageMode.value,
                        aiRepository = aiRepository,
                        ttsHelper = ttsHelper,
                        isGirlfriendModeEnabled = _isGirlfriendMode.value,
                        forceOnDeviceOnly = _useOnDeviceAi.value
                    ).collect { chunk ->
                        accumulated.append(chunk)
                        _aiState.value = AiChatState.Streaming(accumulated.toString())
                    }
                } catch (e: Exception) {
                    if (e is CancellationException && e !is TimeoutCancellationException) throw e
                    if (accumulated.isEmpty()) {
                        com.example.data.ai.OnDeviceAiEngine.streamOnDeviceResponse(
                            context = getApplication(),
                            prompt = lastUserMsg.content,
                            currentLang = _languageMode.value,
                            ttsHelper = ttsHelper
                        ).collect { chunk ->
                            accumulated.append(chunk)
                            _aiState.value = AiChatState.Streaming(accumulated.toString())
                        }
                    } else {
                        throw e
                    }
                }

                val finalAiResponse = accumulated.toString().trim()
                if (finalAiResponse.isNotEmpty()) {
                    val aiMessage = ChatMessageEntity(
                        conversationId = conv.id,
                        role = "model",
                        content = finalAiResponse
                    )
                    dao.insertMessage(aiMessage)
                    _aiState.value = AiChatState.Idle
                } else {
                    _aiState.value = AiChatState.Error("VENKAT AI received an empty response. Please try again.")
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "AI regeneration timed out", e)
                _aiState.value = AiChatState.Error("Generation timed out. Please tap retry to try again.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Error regenerating response", e)
                _aiState.value = AiChatState.Error(e.localizedMessage ?: "Failed to regenerate response.")
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        ttsHelper.shutdown()
        speechRecognizer.stopListening()
        com.example.wakeword.WakeWordService.resumeListening(getApplication())
        activeGenerationJob?.cancel()
        messageCollectionJob?.cancel()
    }
}
