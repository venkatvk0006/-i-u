package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.ui.theme.GeminiBlue
import com.example.ui.theme.GeminiCyan
import com.example.ui.theme.GeminiPurple
import com.example.ui.theme.ThemeMode
import com.example.util.TextToSpeechHelper

@Composable
fun SettingsDialog(
    themeMode: ThemeMode,
    languageMode: String,
    useOnDeviceAi: Boolean,
    isGirlfriendMode: Boolean = true,
    ttsHelper: TextToSpeechHelper,
    onSetThemeMode: (ThemeMode) -> Unit,
    onSetLanguageMode: (String) -> Unit,
    onSetUseOnDeviceAi: (Boolean) -> Unit,
    onSetGirlfriendMode: (Boolean) -> Unit = {},
    onClearAllHistory: () -> Unit,
    onDismiss: () -> Unit
) {
    var showClearConfirmation by remember { mutableStateOf(false) }
    var speechRate by remember { mutableFloatStateOf(ttsHelper.speechRate) }
    var speechPitch by remember { mutableFloatStateOf(ttsHelper.pitch) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
                .testTag("settings_dialog"),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .border(
                                width = 1.5.dp,
                                brush = Brush.linearGradient(listOf(GeminiCyan, GeminiPurple)),
                                shape = CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.venkat_ai_star_icon),
                            contentDescription = "VENKAT AI",
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = "Settings & About",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            ),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "VENKAT AI v1.0",
                            style = MaterialTheme.typography.bodySmall,
                            color = GeminiCyan
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                Spacer(modifier = Modifier.height(12.dp))

                // AI Assistant Engine Mode Section
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = null,
                        tint = GeminiCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "AI Assistant Engine",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                            Text(
                                text = if (useOnDeviceAi) "⚡ Full On-Device AI" else "☁️ Cloud Gemini 3.8",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = if (useOnDeviceAi) GeminiCyan else GeminiPurple
                            )
                            Text(
                                text = if (useOnDeviceAi) {
                                    "100% offline, 0ms instant replies, hardware duty control (torch, wifi, apps) with zero cloud lag."
                                } else {
                                    "Queries cloud Gemini model when internet is connected (with auto on-device fallback)."
                                },
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = useOnDeviceAi,
                            onCheckedChange = onSetUseOnDeviceAi
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Smart Hybrid Girlfriend Mode
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                            Text(
                                text = if (isGirlfriendMode) "❤️ Smart Hybrid Girlfriend Mode" else "🤖 Standard Assistant Mode",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = if (isGirlfriendMode) GeminiPurple else MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (isGirlfriendMode) {
                                    "Sweet & caring Indian AI companion personality for casual offline & online conversations (Tamil, English & Tanglish)."
                                } else {
                                    "Standard neutral assistant personality."
                                },
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = isGirlfriendMode,
                            onCheckedChange = onSetGirlfriendMode
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                Spacer(modifier = Modifier.height(12.dp))

                // Wake Word Settings Section
                val context = androidx.compose.ui.platform.LocalContext.current
                val wakeWordManager = remember(context) { com.example.wakeword.WakeWordManager.getInstance(context) }
                val wakeWordSettings = wakeWordManager.settings
                val isWakeWordOn by wakeWordSettings.isWakeWordEnabled.collectAsState()
                val selectedWakeWord by wakeWordSettings.selectedWakeWord.collectAsState()
                val playChime by wakeWordSettings.playChimeSound.collectAsState()
                val vibrationFeedback by wakeWordSettings.vibrationFeedback.collectAsState()
                val directCalling by wakeWordSettings.directCallingEnabled.collectAsState()
                var sensitivityVal by remember { mutableFloatStateOf(wakeWordSettings.sensitivity.value) }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "🎙️",
                        fontSize = 18.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Offline Wake Words",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                                Text(
                                    text = if (isWakeWordOn) "Background Listening Active" else "Wake Words Disabled",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = if (isWakeWordOn) GeminiCyan else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = if (isWakeWordOn) {
                                        "Listening for: ${selectedWakeWord.phrase}"
                                    } else {
                                        "Activate hands-free via \"Hi Kitty\", \"Hey Jarvis\", \"Hey Siri\", or \"Hey Tamil\"."
                                    },
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = isWakeWordOn,
                                onCheckedChange = { enable ->
                                    if (enable) {
                                        wakeWordManager.enableWakeWord()
                                    } else {
                                        wakeWordManager.disableWakeWord()
                                    }
                                },
                                modifier = Modifier.testTag("wake_word_switch")
                            )
                        }

                        // Wake Word Mode Selector Chips
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Selected Wake Phrase:",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState())
                        ) {
                            com.example.wakeword.WakeWordOption.entries.forEach { option ->
                                val isSelected = selectedWakeWord == option
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isSelected) GeminiCyan.copy(alpha = 0.22f) else MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(
                                        width = if (isSelected) 1.5.dp else 1.dp,
                                        color = if (isSelected) GeminiCyan else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
                                    ),
                                    modifier = Modifier
                                        .clickable { wakeWordSettings.setSelectedWakeWord(option) }
                                        .testTag("wake_word_option_${option.id}")
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp)
                                    ) {
                                        Text(text = option.emoji, fontSize = 12.sp)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = option.displayName,
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                fontSize = 11.sp
                                            ),
                                            color = if (isSelected) GeminiCyan else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }

                        if (isWakeWordOn) {
                            Spacer(modifier = Modifier.height(8.dp))
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Activation Chime Tone",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Switch(
                                    checked = playChime,
                                    onCheckedChange = { wakeWordSettings.setPlayChimeSound(it) }
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Haptic Vibration",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Switch(
                                    checked = vibrationFeedback,
                                    onCheckedChange = { wakeWordSettings.setVibrationFeedback(it) }
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Detection Sensitivity",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = String.format("%.0f%%", sensitivityVal * 100),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = GeminiCyan
                                )
                            }
                            Slider(
                                value = sensitivityVal,
                                onValueChange = {
                                    sensitivityVal = it
                                    wakeWordSettings.setSensitivity(it)
                                },
                                valueRange = 0.2f..1.0f
                            )

                            var confidenceVal by remember { mutableFloatStateOf(wakeWordSettings.confidenceThreshold.value) }
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Strict Wake-Word Confidence",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = String.format("%.0f%%", confidenceVal * 100),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = GeminiPurple
                                )
                            }
                            Slider(
                                value = confidenceVal,
                                onValueChange = {
                                    confidenceVal = it
                                    wakeWordSettings.setConfidenceThreshold(it)
                                },
                                valueRange = 0.50f..0.95f
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Personal Voice Authentication Section (Settings -> Voice Detection -> Personal Voice Authentication)
                var showVoiceRegistrationDialog by remember { mutableStateOf(false) }
                val voiceAuthManager = remember(context) { com.example.voiceauth.VoiceProfileManager.getInstance(context) }
                val isVoiceAuthOn by voiceAuthManager.isAuthEnabled.collectAsState()
                val isProfileRegistered by voiceAuthManager.isRegistered.collectAsState()
                val voiceProfileDetails by voiceAuthManager.activeProfile.collectAsState()
                val voiceAccuracy by voiceAuthManager.accuracyThreshold.collectAsState()
                var voiceAccuracySlider by remember { mutableFloatStateOf(voiceAccuracy) }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = GeminiCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Personal Voice Authentication",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                                Text(
                                    text = if (isVoiceAuthOn) "Personal Voice Lock Active" else "Personal Voice Detection OFF",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = if (isVoiceAuthOn) GeminiCyan else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = if (isVoiceAuthOn) {
                                        "Only responds when YOUR verified voice speaks the wake word."
                                    } else {
                                        "Allows wake words from any speaker. Turn ON to lock AI to your voice."
                                    },
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = isVoiceAuthOn,
                                onCheckedChange = { enable ->
                                    if (enable && !isProfileRegistered) {
                                        showVoiceRegistrationDialog = true
                                    } else {
                                        voiceAuthManager.setAuthEnabled(enable)
                                    }
                                }
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                        Spacer(modifier = Modifier.height(10.dp))

                        // Voice Profile Status
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Voice Profile Status",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = if (isProfileRegistered) "✅ Registered (${voiceProfileDetails?.speakerName ?: "Venkat"})" else "❌ Not Registered",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isProfileRegistered) GeminiCyan else MaterialTheme.colorScheme.error
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Voice Recognition Accuracy Slider
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Voice Match Accuracy",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = String.format("%.0f%%", voiceAccuracySlider * 100),
                                style = MaterialTheme.typography.labelSmall,
                                color = GeminiPurple
                            )
                        }
                        Slider(
                            value = voiceAccuracySlider,
                            onValueChange = {
                                voiceAccuracySlider = it
                                voiceAuthManager.setAccuracyThreshold(it)
                            },
                            valueRange = 0.50f..0.95f
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Action Buttons: Register / Re-register / Delete
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { showVoiceRegistrationDialog = true },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = if (isProfileRegistered) "Re-register Voice" else "Register My Voice",
                                    fontSize = 12.sp
                                )
                            }

                            if (isProfileRegistered) {
                                OutlinedButton(
                                    onClick = { voiceAuthManager.deleteProfile() },
                                    modifier = Modifier.weight(0.8f),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                                ) {
                                    Text("Delete Profile", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }

                if (showVoiceRegistrationDialog) {
                    com.example.voiceauth.VoiceRegistrationDialog(
                        onDismiss = { showVoiceRegistrationDialog = false },
                        onRegistrationComplete = {
                            voiceAuthManager.loadProfile()
                        }
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Offline Contact Calling Mode Section
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = GeminiPurple,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Offline Voice Calling Mode",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                                Text(
                                    text = if (directCalling) "Direct Call (ACTION_CALL)" else "Review in Dialer (ACTION_DIAL)",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = if (directCalling) GeminiPurple else GeminiCyan
                                )
                                Text(
                                    text = if (directCalling) {
                                        "Places call directly upon confirmation (requires CALL_PHONE permission)."
                                    } else {
                                        "Opens standard phone dialer with number pre-filled for safety and review."
                                    },
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = directCalling,
                                onCheckedChange = { wakeWordSettings.setDirectCallingEnabled(it) }
                            )
                        }
                    }
                }

                // Theme Mode Section
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.DarkMode,
                        contentDescription = null,
                        tint = GeminiBlue,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "App Theme",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    ThemeMode.entries.forEach { mode ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(end = 6.dp)
                        ) {
                            RadioButton(
                                selected = themeMode == mode,
                                onClick = { onSetThemeMode(mode) }
                            )
                            Text(
                                text = mode.name.lowercase().replaceFirstChar { it.uppercase() },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Language Section
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Language,
                        contentDescription = null,
                        tint = GeminiPurple,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Default Language",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    listOf("AUTO" to "Auto", "EN" to "English", "TA" to "தமிழ்").forEach { (code, label) ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(
                                selected = languageMode == code,
                                onClick = { onSetLanguageMode(code) }
                            )
                            Text(
                                text = label,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Text To Speech Settings
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.RecordVoiceOver,
                        contentDescription = null,
                        tint = GeminiCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Voice (TTS) Controls",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                // Speech Speed Slider
                Column(modifier = Modifier.padding(top = 8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Speech Rate",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = String.format("%.1fx", speechRate),
                            style = MaterialTheme.typography.labelSmall,
                            color = GeminiCyan
                        )
                    }
                    Slider(
                        value = speechRate,
                        onValueChange = {
                            speechRate = it
                            ttsHelper.speechRate = it
                        },
                        valueRange = 0.5f..2.0f,
                        steps = 5
                    )
                }

                // Speech Pitch Slider
                Column(modifier = Modifier.padding(top = 4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Voice Pitch",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = String.format("%.1fx", speechPitch),
                            style = MaterialTheme.typography.labelSmall,
                            color = GeminiPurple
                        )
                    }
                    Slider(
                        value = speechPitch,
                        onValueChange = {
                            speechPitch = it
                            ttsHelper.pitch = it
                        },
                        valueRange = 0.6f..1.4f,
                        steps = 4
                    )
                }

                // Preview TTS Voice Button
                OutlinedButton(
                    onClick = {
                        val sampleText = if (languageMode == "TA") {
                            "வணக்கம்! நான் உங்கள் வென்கட் ஏஐ."
                        } else {
                            "Hello! I am your intelligent companion VENKAT AI."
                        }
                        ttsHelper.speak(sampleText)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Test Voice Output", fontSize = 13.sp)
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                Spacer(modifier = Modifier.height(12.dp))

                // App Information & Security
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = GeminiBlue,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Architecture & Security",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        InfoRow(label = "AI Engine", value = "Gemini 3.8 Flash")
                        InfoRow(label = "Integration", value = "Firebase AI Logic")
                        InfoRow(label = "App Attestation", value = "Firebase App Check")
                        InfoRow(label = "Local Storage", value = "Jetpack Room Database")
                        InfoRow(label = "Speech Engine", value = "Android Speech & Multi-TTS")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Clear All History Button
                Button(
                    onClick = { showClearConfirmation = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.15f),
                        contentColor = MaterialTheme.colorScheme.error
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteSweep,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "Clear All Chat History", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }

                Spacer(modifier = Modifier.height(14.dp))

                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text(text = "Close", fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (showClearConfirmation) {
        AlertDialog(
            onDismissRequest = { showClearConfirmation = false },
            title = { Text("Clear All History?") },
            text = { Text("This will permanently delete all your conversation history from local storage.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        onClearAllHistory()
                        showClearConfirmation = false
                        onDismiss()
                    }
                ) {
                    Text("Delete All", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirmation = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
