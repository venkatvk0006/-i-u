package com.example.reminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log

object ReminderScheduler {
    private const val TAG = "ReminderScheduler"

    const val ACTION_TRIGGER_REMINDER = "com.example.reminder.ACTION_TRIGGER_REMINDER"
    const val ACTION_DONE = "com.example.reminder.ACTION_DONE"
    const val ACTION_SNOOZE = "com.example.reminder.ACTION_SNOOZE"
    const val ACTION_DISMISS = "com.example.reminder.ACTION_DISMISS"

    const val EXTRA_REMINDER_ID = "extra_reminder_id"
    const val EXTRA_REMINDER_TITLE = "extra_reminder_title"
    const val EXTRA_REMINDER_TIME = "extra_reminder_time"
    const val EXTRA_NOTIFICATION_ID = "extra_notification_id"

    fun scheduleReminder(context: Context, reminder: ReminderEntity) {
        if (!reminder.isEnabled || reminder.isCompleted) {
            cancelReminder(context, reminder.id)
            return
        }

        val now = System.currentTimeMillis()
        var targetTime = reminder.scheduledTimeMillis

        // If target time is in the past for a recurring reminder, calculate next occurrence
        if (targetTime <= now && reminder.repeatFrequency != RepeatFrequency.NONE.name) {
            targetTime = calculateNextOccurrence(targetTime, reminder.repeatFrequency)
        } else if (targetTime <= now) {
            // Expired non-recurring reminder
            return
        }

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

        val intent = Intent(context, ReminderReceiver::class.java).apply {
            action = ACTION_TRIGGER_REMINDER
            putExtra(EXTRA_REMINDER_ID, reminder.id)
            putExtra(EXTRA_REMINDER_TITLE, reminder.title)
            putExtra(EXTRA_REMINDER_TIME, targetTime)
        }

        val requestCode = reminder.id.hashCode()
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        targetTime,
                        pendingIntent
                    )
                } else {
                    alarmManager.setAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        targetTime,
                        pendingIntent
                    )
                }
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    targetTime,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    targetTime,
                    pendingIntent
                )
            }
            Log.i(TAG, "Scheduled reminder '${reminder.title}' at $targetTime (id=${reminder.id})")
        } catch (e: SecurityException) {
            Log.w(TAG, "Exact alarm permission missing, fallback to standard alarm", e)
            alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                targetTime,
                pendingIntent
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to schedule reminder", e)
        }
    }

    fun cancelReminder(context: Context, reminderId: String) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            action = ACTION_TRIGGER_REMINDER
        }
        val requestCode = reminderId.hashCode()
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
            Log.i(TAG, "Cancelled reminder alarm id=$reminderId")
        }
    }

    fun calculateNextOccurrence(baseTime: Long, repeatFreq: String): Long {
        val cal = java.util.Calendar.getInstance()
        cal.timeInMillis = baseTime
        val now = System.currentTimeMillis()

        while (cal.timeInMillis <= now) {
            when (repeatFreq) {
                RepeatFrequency.DAILY.name -> cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
                RepeatFrequency.WEEKLY.name -> cal.add(java.util.Calendar.WEEK_OF_YEAR, 1)
                RepeatFrequency.MONTHLY.name -> cal.add(java.util.Calendar.MONTH, 1)
                RepeatFrequency.YEARLY.name -> cal.add(java.util.Calendar.YEAR, 1)
                else -> {
                    cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
                }
            }
        }
        return cal.timeInMillis
    }
}
