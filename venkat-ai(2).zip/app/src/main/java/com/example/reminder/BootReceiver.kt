package com.example.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.data.local.VenkatAiDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == "android.intent.action.QUICKBOOT_POWERON" ||
            intent.action == "com.htc.intent.action.QUICKBOOT_POWERON"
        ) {
            Log.i(TAG, "Device booted. Restoring scheduled reminders...")
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val db = VenkatAiDatabase.getDatabase(context)
                    val activeReminders = db.reminderDao().getActiveReminders()
                    Log.i(TAG, "Found ${activeReminders.size} active reminders to reschedule.")
                    for (reminder in activeReminders) {
                        ReminderScheduler.scheduleReminder(context, reminder)
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to restore reminders after boot", e)
                }
            }
        }
    }

    companion object {
        private const val TAG = "BootReceiver"
    }
}
