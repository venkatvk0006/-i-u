package com.example.reminder

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

enum class RepeatFrequency {
    NONE,
    DAILY,
    WEEKLY,
    MONTHLY,
    YEARLY
}

@Entity(tableName = "reminders")
data class ReminderEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val scheduledTimeMillis: Long,
    val repeatFrequency: String = RepeatFrequency.NONE.name,
    val isCompleted: Boolean = false,
    val isEnabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val notes: String = ""
)
