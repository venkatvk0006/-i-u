package com.example.reminder

import android.content.Context
import com.example.data.local.VenkatAiDatabase
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed class ReminderOperationResult {
    data class Created(
        val reminder: ReminderEntity,
        val spokenConfirmation: String,
        val displayMessage: String
    ) : ReminderOperationResult()

    data class ClarificationNeeded(
        val question: String
    ) : ReminderOperationResult()

    data object NotAReminder : ReminderOperationResult()
}

class ReminderRepository(private val context: Context) {

    private val dao: ReminderDao = VenkatAiDatabase.getDatabase(context).reminderDao()

    val allReminders: Flow<List<ReminderEntity>> = dao.getAllReminders()

    suspend fun createReminder(reminder: ReminderEntity) {
        dao.insertReminder(reminder)
        ReminderScheduler.scheduleReminder(context, reminder)
    }

    suspend fun updateReminder(reminder: ReminderEntity) {
        dao.updateReminder(reminder)
        if (reminder.isEnabled && !reminder.isCompleted) {
            ReminderScheduler.scheduleReminder(context, reminder)
        } else {
            ReminderScheduler.cancelReminder(context, reminder.id)
        }
    }

    suspend fun setCompleted(id: String, isCompleted: Boolean) {
        dao.setCompleted(id, isCompleted)
        if (isCompleted) {
            ReminderScheduler.cancelReminder(context, id)
        } else {
            val r = dao.getReminderById(id)
            if (r != null && r.isEnabled) {
                ReminderScheduler.scheduleReminder(context, r)
            }
        }
    }

    suspend fun setEnabled(id: String, isEnabled: Boolean) {
        dao.setEnabled(id, isEnabled)
        val r = dao.getReminderById(id)
        if (r != null) {
            if (isEnabled && !r.isCompleted) {
                ReminderScheduler.scheduleReminder(context, r.copy(isEnabled = true))
            } else {
                ReminderScheduler.cancelReminder(context, id)
            }
        }
    }

    suspend fun deleteReminder(id: String) {
        ReminderScheduler.cancelReminder(context, id)
        dao.deleteReminderById(id)
    }

    suspend fun deleteCompleted() {
        dao.deleteCompletedReminders()
    }

    suspend fun processNaturalVoiceOrTextCommand(command: String, lang: String): ReminderOperationResult {
        val parsed = NaturalReminderParser.parse(command)
        if (!parsed.isReminderCommand) {
            return ReminderOperationResult.NotAReminder
        }

        if (parsed.needsClarification || parsed.targetTimeMillis == null) {
            val question = if (lang == "TA") {
                "நீங்கள் எதை, எந்த நேரத்தில் நினைவூட்ட வேண்டும்? (எ.கா: 'மாலை 6 மணிக்கு படிக்க நினைவூட்டு')"
            } else {
                parsed.clarificationPrompt ?: "When and what should I remind you about? (e.g., 'Remind me to study at 6 PM')"
            }
            return ReminderOperationResult.ClarificationNeeded(question)
        }

        val reminder = ReminderEntity(
            title = parsed.title ?: "Reminder",
            scheduledTimeMillis = parsed.targetTimeMillis,
            repeatFrequency = parsed.repeatFrequency.name,
            isEnabled = true,
            isCompleted = false
        )

        createReminder(reminder)

        val formattedDate = SimpleDateFormat("h:mm a, EEE MMM d", Locale.getDefault()).format(Date(reminder.scheduledTimeMillis))
        val repeatText = when (reminder.repeatFrequency) {
            RepeatFrequency.DAILY.name -> " (Repeats Daily)"
            RepeatFrequency.WEEKLY.name -> " (Repeats Weekly)"
            RepeatFrequency.MONTHLY.name -> " (Repeats Monthly)"
            RepeatFrequency.YEARLY.name -> " (Repeats Yearly)"
            else -> ""
        }

        val spokenMsg = if (lang == "TA") {
            "சரி Venkat, ${reminder.title} குறித்து $formattedDate மணிக்கு நினைவூட்டல் அமைக்கப்பட்டது."
        } else {
            "Sure Venkat, I've set a reminder for '${reminder.title}' at $formattedDate$repeatText."
        }

        val displayMsg = "⏰ **Reminder Created:**\n• **Task:** ${reminder.title}\n• **Time:** $formattedDate$repeatText\n• **Status:** Scheduled locally without internet"

        return ReminderOperationResult.Created(
            reminder = reminder,
            spokenConfirmation = spokenMsg,
            displayMessage = displayMsg
        )
    }
}
