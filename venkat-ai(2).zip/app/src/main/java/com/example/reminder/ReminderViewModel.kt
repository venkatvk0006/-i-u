package com.example.reminder

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.util.TextToSpeechHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

class ReminderViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ReminderRepository(application)

    val allReminders: StateFlow<List<ReminderEntity>> = repository.allReminders
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val todayReminders: StateFlow<List<ReminderEntity>> = allReminders.map { list ->
        val cal = Calendar.getInstance()
        val currentDay = cal.get(Calendar.DAY_OF_YEAR)
        val currentYear = cal.get(Calendar.YEAR)

        list.filter {
            cal.timeInMillis = it.scheduledTimeMillis
            cal.get(Calendar.DAY_OF_YEAR) == currentDay && cal.get(Calendar.YEAR) == currentYear && !it.isCompleted
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val upcomingReminders: StateFlow<List<ReminderEntity>> = allReminders.map { list ->
        val cal = Calendar.getInstance()
        val currentDay = cal.get(Calendar.DAY_OF_YEAR)
        val currentYear = cal.get(Calendar.YEAR)

        list.filter {
            cal.timeInMillis = it.scheduledTimeMillis
            val isFutureDay = (cal.get(Calendar.YEAR) > currentYear) ||
                    (cal.get(Calendar.YEAR) == currentYear && cal.get(Calendar.DAY_OF_YEAR) > currentDay)
            isFutureDay && !it.isCompleted
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recurringReminders: StateFlow<List<ReminderEntity>> = allReminders.map { list ->
        list.filter { it.repeatFrequency != RepeatFrequency.NONE.name && !it.isCompleted }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val completedReminders: StateFlow<List<ReminderEntity>> = allReminders.map { list ->
        list.filter { it.isCompleted }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedTab = MutableStateFlow(0) // 0: Today, 1: Upcoming, 2: Recurring, 3: Completed
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    fun setSelectedTab(tab: Int) {
        _selectedTab.value = tab
    }

    fun addReminder(title: String, timeMillis: Long, repeatFrequency: RepeatFrequency, notes: String = "") {
        viewModelScope.launch {
            val entity = ReminderEntity(
                title = title.trim(),
                scheduledTimeMillis = timeMillis,
                repeatFrequency = repeatFrequency.name,
                notes = notes.trim()
            )
            repository.createReminder(entity)
        }
    }

    fun updateReminder(reminder: ReminderEntity) {
        viewModelScope.launch {
            repository.updateReminder(reminder)
        }
    }

    fun toggleComplete(reminder: ReminderEntity) {
        viewModelScope.launch {
            repository.setCompleted(reminder.id, !reminder.isCompleted)
        }
    }

    fun toggleEnabled(reminder: ReminderEntity) {
        viewModelScope.launch {
            repository.setEnabled(reminder.id, !reminder.isEnabled)
        }
    }

    fun deleteReminder(id: String) {
        viewModelScope.launch {
            repository.deleteReminder(id)
        }
    }

    fun clearCompleted() {
        viewModelScope.launch {
            repository.deleteCompleted()
        }
    }

    suspend fun processNaturalCommand(command: String, lang: String): ReminderOperationResult {
        return repository.processNaturalVoiceOrTextCommand(command, lang)
    }
}
