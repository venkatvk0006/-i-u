package com.example.reminder

import java.util.Calendar
import java.util.Locale

data class ParsedReminder(
    val isReminderCommand: Boolean,
    val title: String? = null,
    val targetTimeMillis: Long? = null,
    val repeatFrequency: RepeatFrequency = RepeatFrequency.NONE,
    val needsClarification: Boolean = false,
    val clarificationPrompt: String? = null
)

object NaturalReminderParser {

    /**
     * Parses natural language reminder queries in English, Tamil, and Tanglish.
     * Examples:
     * - "Remind me to study at 6 PM"
     * - "Remind me tomorrow morning"
     * - "Remind me every Sunday"
     * - "நாளை காலை 7 மணிக்கு மாத்திரை சாப்பிட நினைவூட்டு"
     */
    fun parse(input: String): ParsedReminder {
        val raw = input.trim()
        val lower = raw.lowercase(Locale.ROOT)

        val isReminder = lower.contains("remind me") ||
                lower.contains("set a reminder") ||
                lower.contains("create a reminder") ||
                lower.contains("add reminder") ||
                lower.contains("reminder to") ||
                lower.contains("நினைவூட்டு") ||
                lower.contains("ஞாபகப்படுத்து") ||
                lower.contains("நினைவூட்டல்") ||
                lower.contains("ரிமைண்டர்") ||
                lower.contains("याद दिलाना") ||
                lower.contains("रिमाइंडर")

        if (!isReminder) {
            return ParsedReminder(isReminderCommand = false)
        }

        // Clean wake words if present
        var cleaned = lower
            .replace("hi kitty", "")
            .replace("hey jarvis", "")
            .replace("hey siri", "")
            .replace("hey tamil", "")
            .trim()

        // 1. Determine repeat frequency
        var repeatFreq = RepeatFrequency.NONE
        when {
            cleaned.contains("every sunday") || cleaned.contains("ஒவ்வொரு ஞாயிறு") -> repeatFreq = RepeatFrequency.WEEKLY
            cleaned.contains("every monday") || cleaned.contains("ஒவ்வொரு திங்கள்") -> repeatFreq = RepeatFrequency.WEEKLY
            cleaned.contains("every tuesday") || cleaned.contains("ஒவ்வொரு செவ்வாய்") -> repeatFreq = RepeatFrequency.WEEKLY
            cleaned.contains("every wednesday") || cleaned.contains("ஒவ்வொரு புதன்") -> repeatFreq = RepeatFrequency.WEEKLY
            cleaned.contains("every thursday") || cleaned.contains("ஒவ்வொரு வியாழன்") -> repeatFreq = RepeatFrequency.WEEKLY
            cleaned.contains("every friday") || cleaned.contains("ஒவ்வொரு வெள்ளி") -> repeatFreq = RepeatFrequency.WEEKLY
            cleaned.contains("every saturday") || cleaned.contains("ஒவ்வொரு சனி") -> repeatFreq = RepeatFrequency.WEEKLY
            cleaned.contains("every week") || cleaned.contains("weekly") || cleaned.contains("வாரந்தோறும்") -> repeatFreq = RepeatFrequency.WEEKLY
            cleaned.contains("every day") || cleaned.contains("daily") || cleaned.contains("தினமும்") || cleaned.contains("ஒவ்வொரு நாளும்") -> repeatFreq = RepeatFrequency.DAILY
            cleaned.contains("every month") || cleaned.contains("monthly") || cleaned.contains("மாதந்தோறும்") -> repeatFreq = RepeatFrequency.MONTHLY
            cleaned.contains("every year") || cleaned.contains("yearly") || cleaned.contains("வருடந்தோறும்") -> repeatFreq = RepeatFrequency.YEARLY
        }

        // 2. Parse Date offset
        val cal = Calendar.getInstance()
        val now = cal.timeInMillis

        var hasDateSpecified = false
        var targetDayOfWeek: Int? = null

        when {
            cleaned.contains("tomorrow") || cleaned.contains("நாளை") || cleaned.contains("कल") -> {
                cal.add(Calendar.DAY_OF_YEAR, 1)
                hasDateSpecified = true
            }
            cleaned.contains("day after tomorrow") || cleaned.contains("நாளை மறுநாள்") || cleaned.contains("परसों") -> {
                cal.add(Calendar.DAY_OF_YEAR, 2)
                hasDateSpecified = true
            }
            cleaned.contains("sunday") || cleaned.contains("ஞாயிறு") -> {
                targetDayOfWeek = Calendar.SUNDAY
            }
            cleaned.contains("monday") || cleaned.contains("திங்கள்") -> {
                targetDayOfWeek = Calendar.MONDAY
            }
            cleaned.contains("tuesday") || cleaned.contains("செவ்வாய்") -> {
                targetDayOfWeek = Calendar.TUESDAY
            }
            cleaned.contains("wednesday") || cleaned.contains("புதன்") -> {
                targetDayOfWeek = Calendar.WEDNESDAY
            }
            cleaned.contains("thursday") || cleaned.contains("வியாழன்") -> {
                targetDayOfWeek = Calendar.THURSDAY
            }
            cleaned.contains("friday") || cleaned.contains("வெள்ளி") -> {
                targetDayOfWeek = Calendar.FRIDAY
            }
            cleaned.contains("saturday") || cleaned.contains("சனி") -> {
                targetDayOfWeek = Calendar.SATURDAY
            }
        }

        if (targetDayOfWeek != null) {
            val currentDay = cal.get(Calendar.DAY_OF_WEEK)
            var daysUntil = targetDayOfWeek - currentDay
            if (daysUntil <= 0) {
                daysUntil += 7
            }
            cal.add(Calendar.DAY_OF_YEAR, daysUntil)
            hasDateSpecified = true
        }

        // 3. Parse Time (e.g., 6 PM, 6:30 AM, 9:00, 7 o'clock, morning, evening)
        var hasTimeSpecified = false
        var hour = 9 // Default morning hour
        var minute = 0

        val timeRegex = Regex("""(\d{1,2})(?::(\d{2}))?\s*(am|pm|a\.m\.|p\.m\.|o'clock)?""", RegexOption.IGNORE_CASE)
        val match = timeRegex.find(cleaned)

        val isMorning = cleaned.contains("morning") || cleaned.contains("காலை") || cleaned.contains("सुबह")
        val isAfternoon = cleaned.contains("afternoon") || cleaned.contains("மதியம்") || cleaned.contains("दोपहर")
        val isEvening = cleaned.contains("evening") || cleaned.contains("மாலை") || cleaned.contains("शाम")
        val isNight = cleaned.contains("night") || cleaned.contains("இரவு") || cleaned.contains("रात")

        if (match != null) {
            val rawHour = match.groupValues[1].toIntOrNull()
            val rawMin = match.groupValues[2].toIntOrNull() ?: 0
            val amPm = match.groupValues[3].lowercase(Locale.ROOT)

            if (rawHour != null && rawHour in 0..23) {
                hour = rawHour
                minute = rawMin.coerceIn(0, 59)
                hasTimeSpecified = true

                if (amPm.contains("pm") || isAfternoon || isEvening || isNight) {
                    if (hour < 12) hour += 12
                } else if (amPm.contains("am") || isMorning) {
                    if (hour == 12) hour = 0
                } else if (hour in 1..7 && (isEvening || isNight)) {
                    hour += 12
                }
            }
        } else if (isMorning) {
            hour = 9
            minute = 0
            hasTimeSpecified = true
        } else if (isAfternoon) {
            hour = 14
            minute = 0
            hasTimeSpecified = true
        } else if (isEvening) {
            hour = 18
            minute = 0
            hasTimeSpecified = true
        } else if (isNight) {
            hour = 21
            minute = 0
            hasTimeSpecified = true
        }

        // Set time on calendar
        cal.set(Calendar.HOUR_OF_DAY, hour)
        cal.set(Calendar.MINUTE, minute)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)

        // If no explicit date was mentioned and the time today has already passed, bump to tomorrow
        if (!hasDateSpecified && cal.timeInMillis <= now) {
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }

        // 4. Extract Reminder Title
        // Clean wake words and reminder prefixes
        var titleCandidate = raw
            .replace(Regex("""(?i)\b(hi kitty|hey jarvis|hey siri|hey tamil)\b"""), "")
            .replace(Regex("""(?i)\b(please\s+)?(remind me to|remind me|set a reminder to|create a reminder to|add a reminder to|reminder to)\b"""), "")
            .replace(Regex("""(?i)(நினைவூட்டு|ஞாபகப்படுத்து|நினைவூட்டல்|ரிமைண்டர்)"""), "")
            .trim()

        // Strip time/date references from title
        val phrasesToStrip = listOf(
            "tomorrow morning", "tomorrow evening", "tomorrow afternoon", "tomorrow night", "tomorrow",
            "day after tomorrow", "today", "tonight",
            "every sunday", "every monday", "every tuesday", "every wednesday", "every thursday", "every friday", "every saturday",
            "every day", "daily", "weekly", "monthly", "yearly",
            "sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday",
            "morning", "evening", "afternoon", "night",
            "நாளை மறுநாள்", "நாளை", "காலை", "மாலை", "இரவு", "மதியம்"
        )
        var cleanedTitle = titleCandidate
        for (w in phrasesToStrip) {
            cleanedTitle = cleanedTitle.replace(Regex("(?i)\\b$w\\b"), " ")
        }

        // Strip times e.g. "at 6 pm", "at 6:30 am", "6 pm"
        cleanedTitle = cleanedTitle.replace(Regex("""(?i)\bat\s+\d{1,2}(?::\d{2})?\s*(am|pm|a\.m\.|p\.m\.|o'clock)?"""), " ")
        if (match != null) {
            cleanedTitle = cleanedTitle.replace(match.value, " ")
        }
        cleanedTitle = cleanedTitle
            .replace(Regex("""(?i)\b(at|on|for|in)\b"""), " ")
            .replace(Regex("""[.,!?]"""), " ")
            .replace(Regex("""\s+"""), " ")
            .trim()

        if (cleanedTitle.isBlank() || cleanedTitle.length < 2) {
            cleanedTitle = "Reminder"
        }

        // Check if clarification is needed: e.g. "Remind me" with neither time nor clear subject
        if (!hasTimeSpecified && !hasDateSpecified && cleanedTitle == "Reminder") {
            return ParsedReminder(
                isReminderCommand = true,
                needsClarification = true,
                clarificationPrompt = "What would you like me to remind you about, and at what date or time? (e.g., 'Remind me to study at 6 PM')"
            )
        }

        return ParsedReminder(
            isReminderCommand = true,
            title = cleanedTitle.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() },
            targetTimeMillis = cal.timeInMillis,
            repeatFrequency = repeatFreq,
            needsClarification = false
        )
    }
}
