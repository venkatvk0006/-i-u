package com.example.reminder

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.RingtoneManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.local.VenkatAiDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val reminderId = intent.getStringExtra(ReminderScheduler.EXTRA_REMINDER_ID) ?: return
        val notificationId = intent.getIntExtra(
            ReminderScheduler.EXTRA_NOTIFICATION_ID,
            reminderId.hashCode()
        )

        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        when (action) {
            ReminderScheduler.ACTION_TRIGGER_REMINDER -> {
                val title = intent.getStringExtra(ReminderScheduler.EXTRA_REMINDER_TITLE)
                    ?: "Venkat AI Reminder"
                val timeMillis = intent.getLongExtra(
                    ReminderScheduler.EXTRA_REMINDER_TIME,
                    System.currentTimeMillis()
                )

                showReminderNotification(context, notificationManager, reminderId, title, timeMillis, notificationId)

                // Handle repeat or mark done in database
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        val db = VenkatAiDatabase.getDatabase(context)
                        val reminder = db.reminderDao().getReminderById(reminderId)
                        if (reminder != null) {
                            if (reminder.repeatFrequency != RepeatFrequency.NONE.name) {
                                val nextTime = ReminderScheduler.calculateNextOccurrence(
                                    reminder.scheduledTimeMillis,
                                    reminder.repeatFrequency
                                )
                                val updated = reminder.copy(scheduledTimeMillis = nextTime)
                                db.reminderDao().updateReminder(updated)
                                ReminderScheduler.scheduleReminder(context, updated)
                            }
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed to update repeating reminder", e)
                    }
                }
            }

            ReminderScheduler.ACTION_DONE -> {
                notificationManager.cancel(notificationId)
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        val db = VenkatAiDatabase.getDatabase(context)
                        db.reminderDao().setCompleted(reminderId, true)
                        ReminderScheduler.cancelReminder(context, reminderId)
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed to mark reminder done", e)
                    }
                }
            }

            ReminderScheduler.ACTION_SNOOZE -> {
                notificationManager.cancel(notificationId)
                val title = intent.getStringExtra(ReminderScheduler.EXTRA_REMINDER_TITLE) ?: "Reminder"
                val snoozeTime = System.currentTimeMillis() + 10 * 60 * 1000L // 10 minutes snooze

                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        val db = VenkatAiDatabase.getDatabase(context)
                        val reminder = db.reminderDao().getReminderById(reminderId)
                        if (reminder != null) {
                            val updated = reminder.copy(scheduledTimeMillis = snoozeTime, isCompleted = false)
                            db.reminderDao().updateReminder(updated)
                            ReminderScheduler.scheduleReminder(context, updated)
                        } else {
                            val temp = ReminderEntity(
                                id = reminderId,
                                title = title,
                                scheduledTimeMillis = snoozeTime
                            )
                            db.reminderDao().insertReminder(temp)
                            ReminderScheduler.scheduleReminder(context, temp)
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed to snooze reminder", e)
                    }
                }
            }

            ReminderScheduler.ACTION_DISMISS -> {
                notificationManager.cancel(notificationId)
            }
        }
    }

    private fun showReminderNotification(
        context: Context,
        notificationManager: NotificationManager,
        reminderId: String,
        title: String,
        timeMillis: Long,
        notificationId: Int
    ) {
        val channelId = "venkat_ai_reminders"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelName = context.getString(R.string.reminder_channel_name)
            val channelDesc = context.getString(R.string.reminder_channel_desc)
            val channel = NotificationChannel(
                channelId,
                channelName,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = channelDesc
                enableLights(true)
                lightColor = Color.CYAN
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 250, 500)
            }
            notificationManager.createNotificationChannel(channel)
        }

        // Tap opens app
        val contentIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(ReminderScheduler.EXTRA_REMINDER_ID, reminderId)
        }
        val contentPendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            contentIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Action: Done
        val doneIntent = Intent(context, ReminderReceiver::class.java).apply {
            action = ReminderScheduler.ACTION_DONE
            putExtra(ReminderScheduler.EXTRA_REMINDER_ID, reminderId)
            putExtra(ReminderScheduler.EXTRA_NOTIFICATION_ID, notificationId)
        }
        val donePendingIntent = PendingIntent.getBroadcast(
            context,
            notificationId + 1,
            doneIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Action: Snooze (10 mins)
        val snoozeIntent = Intent(context, ReminderReceiver::class.java).apply {
            action = ReminderScheduler.ACTION_SNOOZE
            putExtra(ReminderScheduler.EXTRA_REMINDER_ID, reminderId)
            putExtra(ReminderScheduler.EXTRA_REMINDER_TITLE, title)
            putExtra(ReminderScheduler.EXTRA_NOTIFICATION_ID, notificationId)
        }
        val snoozePendingIntent = PendingIntent.getBroadcast(
            context,
            notificationId + 2,
            snoozeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Action: Dismiss
        val dismissIntent = Intent(context, ReminderReceiver::class.java).apply {
            action = ReminderScheduler.ACTION_DISMISS
            putExtra(ReminderScheduler.EXTRA_NOTIFICATION_ID, notificationId)
        }
        val dismissPendingIntent = PendingIntent.getBroadcast(
            context,
            notificationId + 3,
            dismissIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val formattedTime = SimpleDateFormat("h:mm a, MMM d", Locale.getDefault()).format(Date(timeMillis))

        val alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("⏰ Reminder: $title")
            .setContentText("Scheduled for $formattedTime")
            .setStyle(NotificationCompat.BigTextStyle().bigText("⏰ $title\nScheduled for $formattedTime\nTap to view or manage in VENKAT AI."))
            .setContentIntent(contentPendingIntent)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setSound(alarmSound)
            .setVibrate(longArrayOf(0, 500, 250, 500))
            .addAction(0, context.getString(R.string.reminder_action_done), donePendingIntent)
            .addAction(0, context.getString(R.string.reminder_action_snooze), snoozePendingIntent)
            .addAction(0, context.getString(R.string.reminder_action_dismiss), dismissPendingIntent)

        notificationManager.notify(notificationId, builder.build())
        Log.i(TAG, "Notification shown for reminder '$title'")
    }

    companion object {
        private const val TAG = "ReminderReceiver"
    }
}
