package com.example.calling

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicBoolean

private const val TAG = "OfflineSpeechRecognizer"

enum class SpeechRecognitionState {
    IDLE,
    LISTENING,     // Waiting for user to start speaking
    SPEAKING,      // User is actively speaking (VAD active)
    PROCESSING,    // End-of-speech detected, finalizing text
    ERROR
}

/**
 * VENKAT AI – OFFLINE SPEECH RECOGNITION ENGINE WITH INTELLIGENT VAD
 *
 * Features:
 * 1. On-device / Offline SpeechRecognizer (API 31+ createOnDeviceSpeechRecognizer with fallback).
 * 2. Intelligent Voice Activity Detection (VAD) tracking audio energy (RMS) & partial speech.
 * 3. Automatic End-of-Speech Detection: Distinguishes natural mid-sentence pauses (< 1.5s)
 *    from end of sentence (>= 1.5s silence timeout), auto-submitting hands-free.
 * 4. Partial-text recovery: Never drops spoken words on trailing silence timeouts.
 * 5. Optimized for Tamil, Tanglish, and English cadence.
 */
class OfflineSpeechRecognizer(private val context: Context) {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var speechRecognizer: SpeechRecognizer? = null

    private val _state = MutableStateFlow(SpeechRecognitionState.IDLE)
    val state: StateFlow<SpeechRecognitionState> = _state.asStateFlow()

    private val _isUserSpeaking = MutableStateFlow(false)
    val isUserSpeaking: StateFlow<Boolean> = _isUserSpeaking.asStateFlow()

    private val _rmsLevel = MutableStateFlow(0f)
    val rmsLevel: StateFlow<Float> = _rmsLevel.asStateFlow()

    private val _partialText = MutableStateFlow("")
    val partialText: StateFlow<String> = _partialText.asStateFlow()

    private val _lastRecognizedText = MutableStateFlow("")
    val lastRecognizedText: StateFlow<String> = _lastRecognizedText.asStateFlow()

    private val _isOfflineAvailable = MutableStateFlow(true)
    val isOfflineAvailable: StateFlow<Boolean> = _isOfflineAvailable.asStateFlow()

    // Configurable silence timeout for end-of-speech detection (default 1500ms)
    var silenceTimeoutMs: Long = 1500L

    // VAD tracking variables
    private var hasSpeechStarted = false
    private var currentPartialText = ""
    private var lastSpeechTimestamp = 0L
    private val isDelivered = AtomicBoolean(false)
    private var activeResultCallback: ((String) -> Unit)? = null
    private var activeErrorCallback: ((String) -> Unit)? = null

    // Silence watchdog runnable
    private val silenceWatchdog = Runnable {
        checkSilenceAndFinalize()
    }

    fun isRecognitionAvailable(): Boolean {
        return SpeechRecognizer.isRecognitionAvailable(context)
    }

    /**
     * Starts listening with intelligent Voice Activity Detection and auto-finalization.
     */
    fun startListening(
        language: String = "AUTO",
        timeoutMs: Long = 1500L,
        onPartialResult: ((String) -> Unit)? = null,
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        if (!isRecognitionAvailable()) {
            onError("Speech recognition service not found on this device.")
            return
        }

        // Adjust silence timeout based on language (Tamil has longer vowel pauses)
        silenceTimeoutMs = when (language) {
            "TA" -> 1800L
            else -> timeoutMs.coerceIn(1200L, 3000L)
        }

        stopListening()

        isDelivered.set(false)
        hasSpeechStarted = false
        currentPartialText = ""
        lastSpeechTimestamp = 0L
        _partialText.value = ""
        _isUserSpeaking.value = false
        _rmsLevel.value = 0f
        activeResultCallback = onResult
        activeErrorCallback = onError

        try {
            // Setup on-device offline recognition engine
            speechRecognizer = createConfiguredRecognizer()

            speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    Log.d(TAG, "SpeechRecognizer: Ready for speech (Offline mode)")
                    _state.value = SpeechRecognitionState.LISTENING
                }

                override fun onBeginningOfSpeech() {
                    Log.d(TAG, "SpeechRecognizer: User started speaking")
                    hasSpeechStarted = true
                    _state.value = SpeechRecognitionState.SPEAKING
                    _isUserSpeaking.value = true
                    lastSpeechTimestamp = System.currentTimeMillis()
                    resetSilenceCountdown()
                }

                override fun onRmsChanged(rmsdB: Float) {
                    _rmsLevel.value = rmsdB
                    // If vocal energy is detected above ambient background noise (> 2.5 dB)
                    if (rmsdB > 2.5f) {
                        lastSpeechTimestamp = System.currentTimeMillis()
                        if (hasSpeechStarted) {
                            _isUserSpeaking.value = true
                            resetSilenceCountdown()
                        }
                    }
                }

                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    Log.d(TAG, "SpeechRecognizer: End of speech detected")
                    _state.value = SpeechRecognitionState.PROCESSING
                    _isUserSpeaking.value = false
                    mainHandler.removeCallbacks(silenceWatchdog)
                }

                override fun onError(error: Int) {
                    mainHandler.removeCallbacks(silenceWatchdog)
                    _isUserSpeaking.value = false

                    // Partial-text recovery: if user spoke but system dropped trailing silence
                    val fallbackText = currentPartialText.trim()
                    if (fallbackText.isNotEmpty() && !isDelivered.get()) {
                        Log.i(TAG, "SpeechRecognizer error ($error), but recovered partial text: '$fallbackText'")
                        deliverResult(fallbackText)
                        return
                    }

                    _state.value = SpeechRecognitionState.ERROR
                    val errorMsg = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH -> "No speech detected. Please speak clearly."
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Speech timeout. No command heard."
                        SpeechRecognizer.ERROR_AUDIO -> "Audio recording hardware error."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required."
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech recognizer is busy. Retrying..."
                        SpeechRecognizer.ERROR_CLIENT -> "Speech recognition cancelled."
                        else -> "Voice recognition stopped (Code $error)."
                    }
                    Log.w(TAG, "SpeechRecognizer error: $errorMsg (code $error)")
                    deliverError(errorMsg)
                }

                override fun onResults(results: Bundle?) {
                    mainHandler.removeCallbacks(silenceWatchdog)
                    _state.value = SpeechRecognitionState.IDLE
                    _isUserSpeaking.value = false

                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val primaryMatch = matches?.firstOrNull()?.trim().orEmpty()
                    val finalText = primaryMatch.ifEmpty { currentPartialText.trim() }

                    _lastRecognizedText.value = finalText
                    deliverResult(finalText)
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val partial = matches?.firstOrNull()?.trim().orEmpty()

                    if (partial.isNotEmpty()) {
                        hasSpeechStarted = true
                        _state.value = SpeechRecognitionState.SPEAKING
                        _isUserSpeaking.value = true
                        currentPartialText = partial
                        _partialText.value = partial
                        lastSpeechTimestamp = System.currentTimeMillis()

                        onPartialResult?.invoke(partial)

                        // Reset silence countdown: user just spoke new words
                        resetSilenceCountdown()
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })

            val intent = buildRecognizerIntent(language)
            speechRecognizer?.startListening(intent)

        } catch (e: Exception) {
            Log.e(TAG, "Failed to start offline speech recognizer", e)
            _state.value = SpeechRecognitionState.ERROR
            deliverError(e.localizedMessage ?: "Failed to start voice recognition.")
        }
    }

    private fun createConfiguredRecognizer(): SpeechRecognizer {
        // Android 12+ On-Device Offline Speech Recognizer
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                if (SpeechRecognizer.isOnDeviceRecognitionAvailable(context)) {
                    Log.i(TAG, "Using dedicated on-device speech recognizer")
                    return SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
                }
            } catch (e: Exception) {
                Log.w(TAG, "On-device recognizer check failed, falling back", e)
            }
        }
        return SpeechRecognizer.createSpeechRecognizer(context)
    }

    private fun buildRecognizerIntent(language: String): Intent {
        return Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)

            // Explicit Offline Preference Extra
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)

            // VAD Silence Timeout Extras (supported on Google Speech Recognition)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, silenceTimeoutMs)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, silenceTimeoutMs)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1000L)

            val targetLocale = when (language) {
                "TA" -> "ta-IN"
                "HI" -> "hi-IN"
                else -> "en-US"
            }
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, targetLocale)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, targetLocale)
        }
    }

    private fun resetSilenceCountdown() {
        mainHandler.removeCallbacks(silenceWatchdog)
        mainHandler.postDelayed(silenceWatchdog, silenceTimeoutMs)
    }

    private fun checkSilenceAndFinalize() {
        if (!hasSpeechStarted || isDelivered.get()) return

        val now = System.currentTimeMillis()
        val elapsedSinceSpeech = now - lastSpeechTimestamp

        // If at least silenceTimeoutMs has elapsed since last speech activity
        if (elapsedSinceSpeech >= silenceTimeoutMs) {
            Log.i(TAG, "Intelligent VAD: End of sentence confirmed after ${elapsedSinceSpeech}ms silence. Finalizing.")
            _state.value = SpeechRecognitionState.PROCESSING
            _isUserSpeaking.value = false

            try {
                // Calling stopListening tells the engine we are done and triggers onResults
                speechRecognizer?.stopListening()
            } catch (e: Exception) {
                Log.w(TAG, "Error stopping recognizer on silence", e)
            }

            // Fallback safety: if onResults doesn't arrive within 600ms, deliver partial text
            mainHandler.postDelayed({
                if (!isDelivered.get() && currentPartialText.trim().isNotEmpty()) {
                    Log.i(TAG, "Fallback safety: delivering partial text after stopListening timeout")
                    deliverResult(currentPartialText.trim())
                }
            }, 600L)
        }
    }

    private fun deliverResult(text: String) {
        if (isDelivered.compareAndSet(false, true)) {
            mainHandler.removeCallbacks(silenceWatchdog)
            _state.value = SpeechRecognitionState.IDLE
            activeResultCallback?.invoke(text)
            cleanup()
        }
    }

    private fun deliverError(message: String) {
        if (isDelivered.compareAndSet(false, true)) {
            mainHandler.removeCallbacks(silenceWatchdog)
            _state.value = SpeechRecognitionState.ERROR
            activeErrorCallback?.invoke(message)
            cleanup()
        }
    }

    fun stopListening() {
        mainHandler.removeCallbacks(silenceWatchdog)
        cleanup()
    }

    private fun cleanup() {
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.destroy()
        } catch (e: Exception) {
            Log.w(TAG, "Error cleaning up speech recognizer", e)
        } finally {
            speechRecognizer = null
            _state.value = SpeechRecognitionState.IDLE
            _isUserSpeaking.value = false
        }
    }
}
