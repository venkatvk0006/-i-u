package com.example.wakeword

import kotlin.math.max
import kotlin.math.min

data class StrictWakeWordResult(
    val isMatch: Boolean,
    val matchedWakeWord: String?,
    val confidence: Float,
    val remainderCommand: String,
    val reason: String
)

/**
 * VENKAT AI – STRICT WAKE WORD VERIFICATION ENGINE
 * Enforces strict phrase matching and rejects partial, sound-alike, or non-wake-word utterances.
 *
 * Registered Wake Words:
 * 1. "Hi Kitty"
 * 2. "Hey Jarvis"
 * 3. "Hey Siri"
 * 4. "Hey Tamil" (and "ஹே தமிழ்")
 */
object StrictWakeWordVerifier {

    private val REGISTERED_WAKE_WORDS = listOf(
        RegisteredWord("Hi Kitty", listOf("hi kitty", "ஹாய் கிட்டி", "हाय किट्टी")),
        RegisteredWord("Hey Jarvis", listOf("hey jarvis", "hey jarvise", "ஹே ஜார்விஸ்", "ஹே ஜார்வைஸ்", "हे जार्विस")),
        RegisteredWord("Hey Siri", listOf("hey siri", "ஹே சிரி", "हे सिरी")),
        RegisteredWord("Hey Tamil", listOf("hey tamil", "hey tamizh", "ஹே தமிழ்", "வணக்கம் தமிழ்"))
    )

    // False activation blacklist: common sound-alikes that MUST NOT trigger
    private val REJECT_BLACKLIST = listOf(
        "aathi kitta", "aathi", "kitta", "open youtube", "open camera", "turn on", "call arun",
        "what is", "did you", "how are", "good morning", "hello", "hi there"
    )

    private data class RegisteredWord(
        val canonicalName: String,
        val validPhrases: List<String>
    )

    /**
     * Strictly verifies whether an input utterance starts with or contains an exact registered wake word.
     */
    fun verify(
        rawCandidate: String,
        confidenceThreshold: Float = 0.75f,
        selectedOption: WakeWordOption = WakeWordOption.ALL
    ): StrictWakeWordResult {
        val clean = rawCandidate.lowercase().trim()
            .replace(Regex("""[.,!?;:]"""), " ")
            .replace(Regex("""\s+"""), " ")
            .trim()

        if (clean.isBlank()) {
            return StrictWakeWordResult(
                isMatch = false,
                matchedWakeWord = null,
                confidence = 0f,
                remainderCommand = "",
                reason = "Empty utterance."
            )
        }

        // 1. Explicit sound-alike blacklist check
        for (blacklistWord in REJECT_BLACKLIST) {
            if (clean == blacklistWord || clean.startsWith("$blacklistWord ")) {
                return StrictWakeWordResult(
                    isMatch = false,
                    matchedWakeWord = null,
                    confidence = 0.15f,
                    remainderCommand = "",
                    reason = "Sound-alike/unrelated phrase explicitly rejected ('$blacklistWord')."
                )
            }
        }

        // 2. Reject isolated partials ("Jarvis", "Kitty", "Siri", "Tamil" without prefix)
        val isolatedPartials = listOf("jarvis", "jarvise", "kitty", "siri", "tamil", "tamizh", "கிட்டி", "ஜார்விஸ்", "சிரி")
        for (partial in isolatedPartials) {
            if (clean == partial || clean.startsWith("$partial ") && !clean.startsWith("hey ") && !clean.startsWith("hi ") && !clean.startsWith("ஹே ") && !clean.startsWith("ஹாய் ")) {
                return StrictWakeWordResult(
                    isMatch = false,
                    matchedWakeWord = null,
                    confidence = 0.40f,
                    remainderCommand = "",
                    reason = "Partial wake word rejected. Full phrase required (e.g. 'Hey $partial')."
                )
            }
        }

        // 3. Match against allowed registered words
        val allowedTargets = when (selectedOption) {
            WakeWordOption.HI_KITTY -> REGISTERED_WAKE_WORDS.filter { it.canonicalName == "Hi Kitty" }
            WakeWordOption.HEY_JARVIS -> REGISTERED_WAKE_WORDS.filter { it.canonicalName == "Hey Jarvis" }
            WakeWordOption.HEY_SIRI -> REGISTERED_WAKE_WORDS.filter { it.canonicalName == "Hey Siri" }
            WakeWordOption.HEY_TAMIL -> REGISTERED_WAKE_WORDS.filter { it.canonicalName == "Hey Tamil" }
            WakeWordOption.ALL -> REGISTERED_WAKE_WORDS
        }

        for (target in allowedTargets) {
            for (phrase in target.validPhrases) {
                // Check exact match
                if (clean == phrase) {
                    return StrictWakeWordResult(
                        isMatch = true,
                        matchedWakeWord = target.canonicalName,
                        confidence = 1.0f,
                        remainderCommand = "",
                        reason = "Exact wake word phrase matched."
                    )
                }

                // Check prefix match: e.g. "Hey Jarvis open YouTube"
                if (clean.startsWith("$phrase ")) {
                    val remainder = clean.removePrefix("$phrase ").trim()
                    return StrictWakeWordResult(
                        isMatch = true,
                        matchedWakeWord = target.canonicalName,
                        confidence = 0.95f,
                        remainderCommand = remainder,
                        reason = "Wake word prefix matched."
                    )
                }

                // Check Levenshtein similarity on the leading tokens
                val candidateTokens = clean.split(" ")
                val phraseTokens = phrase.split(" ")
                if (candidateTokens.size >= phraseTokens.size) {
                    val candidatePrefix = candidateTokens.take(phraseTokens.size).joinToString(" ")
                    val similarity = calculateSimilarity(candidatePrefix, phrase)

                    if (similarity >= confidenceThreshold) {
                        val remainder = candidateTokens.drop(phraseTokens.size).joinToString(" ")
                        return StrictWakeWordResult(
                            isMatch = true,
                            matchedWakeWord = target.canonicalName,
                            confidence = similarity,
                            remainderCommand = remainder,
                            reason = "Confident wake word phrase match (Score: ${String.format("%.2f", similarity)})."
                        )
                    }
                }
            }
        }

        return StrictWakeWordResult(
            isMatch = false,
            matchedWakeWord = null,
            confidence = 0.1f,
            remainderCommand = "",
            reason = "No registered wake word detected in utterance."
        )
    }

    private fun calculateSimilarity(s1: String, s2: String): Float {
        val maxLen = max(s1.length, s2.length)
        if (maxLen == 0) return 1.0f
        val distance = computeLevenshtein(s1, s2)
        return (1.0f - (distance.toFloat() / maxLen)).coerceIn(0.0f, 1.0f)
    }

    private fun computeLevenshtein(s1: String, s2: String): Int {
        val dp = Array(s1.length + 1) { IntArray(s2.length + 1) }
        for (i in 0..s1.length) dp[i][0] = i
        for (j in 0..s2.length) dp[0][j] = j

        for (i in 1..s1.length) {
            for (j in 1..s2.length) {
                val cost = if (s1[i - 1] == s2[j - 1]) 0 else 1
                dp[i][j] = min(
                    min(dp[i - 1][j] + 1, dp[i][j - 1] + 1),
                    dp[i - 1][j - 1] + cost
                )
            }
        }
        return dp[s1.length][s2.length]
    }
}
