package com.example.wakeword

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R

private const val TAG = "WakeWordService"
private const val CHANNEL_ID = "venkat_ai_wake_word_channel"
private const val NOTIFICATION_ID = 2048

/**
 * Foreground Service for background offline wake-word detection.
 * Supports: "Hi Kitty", "Hey Jarvis", "Hey Siri", "Hey Tamil".
 * Conforms strictly to Android 14+ foreground service microphone policy.
 */
class WakeWordService : Service() {

    private lateinit var wakeWordEngine: WakeWordEngine
    private lateinit var settings: WakeWordSettings
    private var toneGenerator: ToneGenerator? = null

    override fun onCreate() {
        super.onCreate()
        serviceInstance = this
        Log.i(TAG, "WakeWordService created")
        settings = WakeWordSettings.getInstance(this)
        wakeWordEngine = WakeWordEngine(this)
        createNotificationChannel()

        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 90)
        } catch (e: Exception) {
            Log.w(TAG, "ToneGenerator could not be created", e)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START

        if (action == ACTION_STOP) {
            Log.i(TAG, "Stop action received in WakeWordService")
            settings.setWakeWordEnabled(false)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        // Start Foreground Notification
        val notification = buildForegroundNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        // Begin offline acoustic listening with multi-wake-word callback
        wakeWordEngine.startListening { matchedWakeWord ->
            onWakeWordTriggered(matchedWakeWord)
        }

        return START_STICKY
    }

    private fun onWakeWordTriggered(matchedWakeWord: String) {
        Log.i(TAG, "Wake word '$matchedWakeWord' triggered globally from WakeWordService!")

        // 1. Wake the screen and acquire temporary wake lock for Lock Screen / Screen-Off
        wakeUpScreen()

        // 2. Chime tone
        if (settings.playChimeSound.value) {
            try {
                toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP2, 160)
            } catch (e: Exception) {
                Log.w(TAG, "Error playing chime tone", e)
            }
        }

        // 3. Vibration feedback
        if (settings.vibrationFeedback.value) {
            vibrateDevice()
        }

        // 4. Immediately pause wake-word engine to prevent repeated detection and release mic for recognition
        wakeWordEngine.pauseListening()

        // 5. Launch or bring MainActivity to the foreground over lock screen
        val openIntent = Intent(this, MainActivity::class.java).apply {
            this.flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            putExtra(EXTRA_WAKE_WORD_TRIGGERED, true)
            putExtra(EXTRA_WAKE_WORD_NAME, matchedWakeWord)
            putExtra(EXTRA_WAKE_TIMESTAMP, System.currentTimeMillis())
        }

        try {
            startActivity(openIntent)
        } catch (e: Exception) {
            Log.w(TAG, "Direct activity start restricted by OS. Posting heads-up wake notification", e)
        }

        // 6. Update notification with high-priority heads-up full-screen alert
        notifyWakeAlert(openIntent, matchedWakeWord)
    }

    private fun wakeUpScreen() {
        try {
            val powerManager = getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager
            @Suppress("DEPRECATION")
            val wakeLock = powerManager?.newWakeLock(
                android.os.PowerManager.SCREEN_BRIGHT_WAKE_LOCK or
                        android.os.PowerManager.ACQUIRE_CAUSES_WAKEUP or
                        android.os.PowerManager.ON_AFTER_RELEASE,
                "venkatai:global_wake_word_lock"
            )
            wakeLock?.acquire(8000L) // 8 seconds to allow user interaction
        } catch (e: Exception) {
            Log.w(TAG, "Error acquiring WakeLock for screen wakeup", e)
        }
    }

    private fun vibrateDevice() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(100, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                @Suppress("DEPRECATION")
                vibrator?.vibrate(100)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Vibrator error", e)
        }
    }

    private fun buildForegroundNotification(): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, WakeWordService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val wakePhraseText = when (settings.selectedWakeWord.value) {
            WakeWordOption.ALL -> "Say \"Hi Kitty\", \"Hey Jarvis\", \"Hey Siri\", or \"Hey Tamil\""
            else -> "Say \"${settings.selectedWakeWord.value.phrase}\" to activate"
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("VENKAT AI • Offline Listening")
            .setContentText(wakePhraseText)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(openAppPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                "Stop Listening",
                stopPendingIntent
            )
            .addAction(
                android.R.drawable.ic_menu_view,
                "Open App",
                openAppPendingIntent
            )
            .build()
    }

    private fun notifyWakeAlert(targetIntent: Intent, matchedWakeWord: String) {
        val pendingIntent = PendingIntent.getActivity(
            this,
            2,
            targetIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val iconEmoji = when (matchedWakeWord) {
            "Hey Jarvis" -> "⚡"
            "Hey Siri" -> "🍎"
            "Hey Tamil" -> "✨"
            else -> "🐱"
        }

        val wakeNotification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("$iconEmoji \"$matchedWakeWord\" Activated!")
            .setContentText("VENKAT AI: \"Hi Venkat, I am listening.\"")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setFullScreenIntent(pendingIntent, true)
            .setAutoCancel(true)
            .build()

        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID + 1, wakeNotification)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "VENKAT AI Wake Word"
            val descriptionText = "Persistent microphone notification for offline wake word detection"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i(TAG, "WakeWordService destroyed")
        if (serviceInstance == this) {
            serviceInstance = null
        }
        wakeWordEngine.stopListening()
        try {
            toneGenerator?.release()
        } catch (e: Exception) {
            Log.w(TAG, "Error releasing tone generator", e)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.example.wakeword.ACTION_START"
        const val ACTION_STOP = "com.example.wakeword.ACTION_STOP"
        const val EXTRA_WAKE_WORD_TRIGGERED = "extra_wake_word_triggered"
        const val EXTRA_WAKE_WORD_NAME = "extra_wake_word_name"
        const val EXTRA_WAKE_TIMESTAMP = "extra_wake_timestamp"

        @Volatile
        var serviceInstance: WakeWordService? = null
            private set

        fun pauseListening(context: Context? = null) {
            serviceInstance?.wakeWordEngine?.pauseListening()
        }

        fun resumeListening(context: Context? = null) {
            serviceInstance?.wakeWordEngine?.resumeListening()
        }

        fun startService(context: Context) {
            val intent = Intent(context, WakeWordService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, WakeWordService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }
}
