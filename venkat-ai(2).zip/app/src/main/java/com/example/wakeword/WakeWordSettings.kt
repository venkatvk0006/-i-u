package com.example.wakeword

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class WakeWordOption(
    val id: String,
    val displayName: String,
    val phrase: String,
    val emoji: String
) {
    ALL("ALL", "All Wake Words", "Hi Kitty / Hey Jarvis / Hey Siri / Hey Tamil", "🌟"),
    HI_KITTY("HI_KITTY", "Hi Kitty", "Hi Kitty", "🐱"),
    HEY_JARVIS("HEY_JARVIS", "Hey Jarvis", "Hey Jarvis", "⚡"),
    HEY_SIRI("HEY_SIRI", "Hey Siri", "Hey Siri", "🍎"),
    HEY_TAMIL("HEY_TAMIL", "Hey Tamil", "Hey Tamil (ஹே தமிழ்)", "✨")
}

/**
 * Persisted settings for offline wake-word detection engine & accuracy controls.
 * Supports "Hi Kitty", "Hey Jarvis", "Hey Siri", and "Hey Tamil".
 */
class WakeWordSettings(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _isWakeWordEnabled = MutableStateFlow(prefs.getBoolean(KEY_WAKE_WORD_ENABLED, true))
    val isWakeWordEnabled: StateFlow<Boolean> = _isWakeWordEnabled.asStateFlow()

    private val _selectedWakeWord = MutableStateFlow(
        WakeWordOption.entries.firstOrNull { it.id == prefs.getString(KEY_SELECTED_WAKE_WORD, WakeWordOption.ALL.id) }
            ?: WakeWordOption.ALL
    )
    val selectedWakeWord: StateFlow<WakeWordOption> = _selectedWakeWord.asStateFlow()

    private val _playChimeSound = MutableStateFlow(prefs.getBoolean(KEY_PLAY_CHIME, true))
    val playChimeSound: StateFlow<Boolean> = _playChimeSound.asStateFlow()

    private val _vibrationFeedback = MutableStateFlow(prefs.getBoolean(KEY_VIBRATION, true))
    val vibrationFeedback: StateFlow<Boolean> = _vibrationFeedback.asStateFlow()

    private val _sensitivity = MutableStateFlow(prefs.getFloat(KEY_SENSITIVITY, 0.6f))
    val sensitivity: StateFlow<Float> = _sensitivity.asStateFlow()

    private val _directCallingEnabled = MutableStateFlow(prefs.getBoolean(KEY_DIRECT_CALLING, false))
    val directCallingEnabled: StateFlow<Boolean> = _directCallingEnabled.asStateFlow()

    // Configurable Wake Word Accuracy Controls
    private val _confidenceThreshold = MutableStateFlow(prefs.getFloat(KEY_CONFIDENCE_THRESHOLD, 0.75f))
    val confidenceThreshold: StateFlow<Float> = _confidenceThreshold.asStateFlow()

    private val _noiseFilteringEnabled = MutableStateFlow(prefs.getBoolean(KEY_NOISE_FILTERING, true))
    val noiseFilteringEnabled: StateFlow<Boolean> = _noiseFilteringEnabled.asStateFlow()

    private val _detectionCooldownMs = MutableStateFlow(prefs.getLong(KEY_COOLDOWN_MS, 3000L))
    val detectionCooldownMs: StateFlow<Long> = _detectionCooldownMs.asStateFlow()

    private val _minPhraseDurationMs = MutableStateFlow(prefs.getLong(KEY_MIN_DURATION_MS, 350L))
    val minPhraseDurationMs: StateFlow<Long> = _minPhraseDurationMs.asStateFlow()

    fun setWakeWordEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_WAKE_WORD_ENABLED, enabled).apply()
        _isWakeWordEnabled.value = enabled
    }

    fun setSelectedWakeWord(option: WakeWordOption) {
        prefs.edit().putString(KEY_SELECTED_WAKE_WORD, option.id).apply()
        _selectedWakeWord.value = option
    }

    fun setPlayChimeSound(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_PLAY_CHIME, enabled).apply()
        _playChimeSound.value = enabled
    }

    fun setVibrationFeedback(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_VIBRATION, enabled).apply()
        _vibrationFeedback.value = enabled
    }

    fun setSensitivity(value: Float) {
        val clamped = value.coerceIn(0.1f, 1.0f)
        prefs.edit().putFloat(KEY_SENSITIVITY, clamped).apply()
        _sensitivity.value = clamped
    }

    fun setDirectCallingEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_DIRECT_CALLING, enabled).apply()
        _directCallingEnabled.value = enabled
    }

    fun setConfidenceThreshold(value: Float) {
        val clamped = value.coerceIn(0.50f, 0.95f)
        prefs.edit().putFloat(KEY_CONFIDENCE_THRESHOLD, clamped).apply()
        _confidenceThreshold.value = clamped
    }

    fun setNoiseFilteringEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_NOISE_FILTERING, enabled).apply()
        _noiseFilteringEnabled.value = enabled
    }

    fun setDetectionCooldownMs(ms: Long) {
        val clamped = ms.coerceIn(1500L, 5000L)
        prefs.edit().putLong(KEY_COOLDOWN_MS, clamped).apply()
        _detectionCooldownMs.value = clamped
    }

    companion object {
        private const val PREFS_NAME = "venkat_ai_wake_word_prefs"
        private const val KEY_WAKE_WORD_ENABLED = "key_wake_word_enabled"
        private const val KEY_SELECTED_WAKE_WORD = "key_selected_wake_word"
        private const val KEY_PLAY_CHIME = "key_play_chime"
        private const val KEY_VIBRATION = "key_vibration"
        private const val KEY_SENSITIVITY = "key_sensitivity"
        private const val KEY_DIRECT_CALLING = "key_direct_calling"
        private const val KEY_CONFIDENCE_THRESHOLD = "key_confidence_threshold"
        private const val KEY_NOISE_FILTERING = "key_noise_filtering"
        private const val KEY_COOLDOWN_MS = "key_cooldown_ms"
        private const val KEY_MIN_DURATION_MS = "key_min_duration_ms"

        @Volatile
        private var instance: WakeWordSettings? = null

        fun getInstance(context: Context): WakeWordSettings {
            return instance ?: synchronized(this) {
                instance ?: WakeWordSettings(context.applicationContext).also { instance = it }
            }
        }
    }
}
