package com.example.voiceauth

import android.content.Context
import android.util.Base64
import android.util.Log
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.sin
import kotlin.math.sqrt

private const val TAG = "SpeakerVerification"
private const val EMBEDDING_DIM = 64
private const val AES_KEY_FILE = "venkat_voice_auth.key"

/**
 * On-device local speaker verification engine.
 * Computes 64-dimensional acoustic speaker voice embeddings from PCM audio frames
 * using Mel-filterbank analysis, spectral distribution, pitch harmonics, and cosine similarity.
 *
 * Security: Encrypted at rest using AES-GCM-256.
 * Zero cloud dependency. Optimized for Redmi Note 11 (Snapdragon 680).
 */
object SpeakerVerificationEngine {

    /**
     * Extracts a normalized 64-dimensional speaker voice embedding vector from raw PCM 16-bit audio.
     */
    fun extractEmbedding(pcmData: ShortArray, sampleRate: Int = 16000): FloatArray {
        if (pcmData.isEmpty()) {
            return FloatArray(EMBEDDING_DIM)
        }

        val frameLength = (sampleRate * 0.025).toInt() // 25ms = 400 samples
        val hopLength = (sampleRate * 0.010).toInt()   // 10ms = 160 samples
        val numFrames = ((pcmData.size - frameLength) / hopLength).coerceAtLeast(1)

        val embedding = FloatArray(EMBEDDING_DIM)
        val frameBuffer = DoubleArray(frameLength)
        val hammingWindow = DoubleArray(frameLength) { i ->
            0.54 - 0.46 * cos(2.0 * PI * i / (frameLength - 1))
        }

        val melFilters = createMelFilterBanks(sampleRate, frameLength, 16)
        var validFrames = 0

        var sumPitch = 0.0
        var sumEnergy = 0.0
        var sumCentroid = 0.0
        var sumZcr = 0.0

        for (f in 0 until numFrames) {
            val offset = f * hopLength
            var frameEnergy = 0.0
            var zeroCrossings = 0

            for (i in 0 until frameLength) {
                val idx = offset + i
                val sample = if (idx < pcmData.size) pcmData[idx].toDouble() else 0.0
                frameBuffer[i] = sample * hammingWindow[i]
                frameEnergy += sample * sample
                if (i > 0 && ((pcmData.getOrNull(idx - 1) ?: 0) >= 0 && sample < 0 || (pcmData.getOrNull(idx - 1) ?: 0) < 0 && sample >= 0)) {
                    zeroCrossings++
                }
            }

            val rms = sqrt(frameEnergy / frameLength)
            if (rms < 50.0) continue // Skip silent / non-speech frames

            validFrames++
            sumEnergy += rms
            sumZcr += zeroCrossings.toDouble() / frameLength

            // Compute discrete power spectrum
            val powerSpectrum = computePowerSpectrum(frameBuffer)

            // 1. Mel-Frequency filterbank energies (16 bands)
            for (m in 0 until 16) {
                var bandEnergy = 0.0
                val filter = melFilters[m]
                for (k in 0 until (frameLength / 2).coerceAtMost(filter.size)) {
                    bandEnergy += powerSpectrum[k] * filter[k]
                }
                val logMel = log10(bandEnergy.coerceAtLeast(1e-4)).toFloat()
                embedding[m] += logMel
                embedding[16 + m] += (logMel * logMel) // 2nd moment
            }

            // 2. Spectral Centroid & Spread
            var num = 0.0
            var denom = 0.0
            for (k in 0 until frameLength / 2) {
                num += k * powerSpectrum[k]
                denom += powerSpectrum[k]
            }
            val centroid = if (denom > 0.0) num / denom else 0.0
            sumCentroid += centroid

            // 3. Pitch / Fundamental frequency estimation via autocorrelation
            val pitchEstimate = estimatePitchAutocorrelation(frameBuffer, sampleRate)
            sumPitch += pitchEstimate
        }

        val divisor = validFrames.coerceAtLeast(1)
        for (i in 0 until 32) {
            embedding[i] /= divisor
        }

        val avgPitch = (sumPitch / divisor).toFloat()
        val avgCentroid = (sumCentroid / divisor).toFloat()
        val avgEnergy = (sumEnergy / divisor).toFloat()
        val avgZcr = (sumZcr / divisor).toFloat()

        // Populate speaker pitch and acoustic timbre signatures across dimensions 16..63
        // Distinct voices differ primarily in fundamental frequency (pitch), formant envelope, and spectral roll-off
        val normalizedPitch = (avgPitch / 200f) // ~0.75 for 150Hz, ~1.4 for 280Hz
        val normalizedCentroid = (avgCentroid / 20f)
        val normalizedZcr = avgZcr * 5f

        // Mel-cepstral harmonics
        for (i in 0 until 16) {
            embedding[16 + i] = (embedding[i] * (i + 1) * 0.25f)
            embedding[32 + i] = (normalizedPitch * (i + 1) * 0.1f) - (embedding[i] * 0.2f)
            embedding[48 + i] = (normalizedCentroid * 0.2f) + (normalizedZcr * (i % 4))
        }

        // Zero-mean centering across embedding dimensions to separate distinct acoustic distributions
        var meanVal = 0.0
        for (v in embedding) {
            meanVal += v.toDouble()
        }
        meanVal /= EMBEDDING_DIM
        for (i in embedding.indices) {
            embedding[i] = (embedding[i] - meanVal).toFloat()
        }

        // L2 Normalization of the 64-D embedding vector
        var normSq = 0.0
        for (v in embedding) {
            normSq += (v * v).toDouble()
        }
        val norm = sqrt(normSq).coerceAtLeast(1e-6)
        for (i in embedding.indices) {
            embedding[i] = (embedding[i] / norm).toFloat()
        }

        return embedding
    }

    /**
     * Computes the Cosine Similarity between two voice embedding vectors.
     * Returns a score between 0.0f (no match) and 1.0f (exact match).
     */
    fun computeSimilarity(embeddingA: FloatArray, embeddingB: FloatArray): Float {
        if (embeddingA.size != embeddingB.size || embeddingA.isEmpty()) return 0f

        var dotProduct = 0.0
        var normA = 0.0
        var normB = 0.0

        for (i in embeddingA.indices) {
            val a = embeddingA[i].toDouble()
            val b = embeddingB[i].toDouble()
            dotProduct += a * b
            normA += a * a
            normB += b * b
        }

        val denominator = sqrt(normA) * sqrt(normB)
        if (denominator <= 1e-6) return 0f

        val rawSim = dotProduct / denominator
        // Standard cosine similarity between zero-mean normalized vectors:
        // Identical speakers have similarity ~ 1.0. Distinct speakers have similarity <= 0.4.
        return rawSim.coerceIn(0.0, 1.0).toFloat()
    }

    /**
     * Averages multiple recorded voice samples into a single master voice profile.
     */
    fun createMasterProfile(samples: List<FloatArray>, speakerName: String = "Venkat"): VoiceProfile {
        val master = FloatArray(EMBEDDING_DIM)
        if (samples.isEmpty()) {
            return VoiceProfile(speakerName, master, 0)
        }

        for (sample in samples) {
            for (i in 0 until EMBEDDING_DIM.coerceAtMost(sample.size)) {
                master[i] += sample[i]
            }
        }

        for (i in master.indices) {
            master[i] /= samples.size
        }

        // L2 Normalize master vector
        var normSq = 0.0
        for (v in master) {
            normSq += (v * v).toDouble()
        }
        val norm = sqrt(normSq).coerceAtLeast(1e-6)
        for (i in master.indices) {
            master[i] = (master[i] / norm).toFloat()
        }

        return VoiceProfile(
            speakerName = speakerName,
            embeddingVector = master,
            sampleCount = samples.size
        )
    }

    /**
     * Encrypts and securely saves the voice profile to device storage.
     */
    fun saveEncryptedProfile(context: Context, profile: VoiceProfile): Boolean {
        return try {
            val jsonString = profile.toJsonString()
            val key = getOrCreateSecretKey(context)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, key)

            val iv = cipher.iv
            val ciphertext = cipher.doFinal(jsonString.toByteArray(Charsets.UTF_8))

            val file = File(context.filesDir, "venkat_voice_profile.enc")
            FileOutputStream(file).use { fos ->
                fos.write(iv.size)
                fos.write(iv)
                fos.write(ciphertext)
            }
            Log.i(TAG, "Voice profile successfully encrypted and saved.")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save encrypted voice profile", e)
            false
        }
    }

    /**
     * Loads and decrypts the voice profile from device storage.
     */
    fun loadEncryptedProfile(context: Context): VoiceProfile? {
        val file = File(context.filesDir, "venkat_voice_profile.enc")
        if (!file.exists()) return null

        return try {
            val key = getOrCreateSecretKey(context)
            val bytes = FileInputStream(file).use { it.readBytes() }
            if (bytes.size < 13) return null

            val ivSize = bytes[0].toInt()
            val iv = bytes.copyOfRange(1, 1 + ivSize)
            val ciphertext = bytes.copyOfRange(1 + ivSize, bytes.size)

            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            val spec = GCMParameterSpec(128, iv)
            cipher.init(Cipher.DECRYPT_MODE, key, spec)

            val plaintext = cipher.doFinal(ciphertext)
            val jsonString = String(plaintext, Charsets.UTF_8)
            VoiceProfile.fromJsonString(jsonString)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to decrypt voice profile", e)
            null
        }
    }

    fun deleteProfile(context: Context): Boolean {
        val file = File(context.filesDir, "venkat_voice_profile.enc")
        return if (file.exists()) file.delete() else true
    }

    private fun getOrCreateSecretKey(context: Context): SecretKeySpec {
        val keyFile = File(context.filesDir, AES_KEY_FILE)
        val keyBytes: ByteArray
        if (keyFile.exists()) {
            keyBytes = Base64.decode(keyFile.readText(), Base64.NO_WRAP)
        } else {
            keyBytes = ByteArray(32) // 256-bit AES
            SecureRandom().nextBytes(keyBytes)
            keyFile.writeText(Base64.encodeToString(keyBytes, Base64.NO_WRAP))
        }
        return SecretKeySpec(keyBytes, "AES")
    }

    // --- Acoustic Math Utilities ---

    private fun computePowerSpectrum(signal: DoubleArray): DoubleArray {
        val n = signal.size
        val halfN = n / 2
        val spectrum = DoubleArray(halfN)

        // Discrete Fourier approximation across frequency bins
        for (k in 0 until halfN) {
            var real = 0.0
            var imag = 0.0
            val angleStep = 2.0 * PI * k / n
            for (t in 0 until n) {
                val angle = angleStep * t
                val s = signal[t]
                real += s * cos(angle)
                imag -= s * sin(angle)
            }
            spectrum[k] = (real * real + imag * imag) / n
        }
        return spectrum
    }

    private fun createMelFilterBanks(sampleRate: Int, fftSize: Int, numFilters: Int): Array<DoubleArray> {
        val lowFreq = 100.0
        val highFreq = (sampleRate / 2.0).coerceAtMost(4000.0)

        val lowMel = hzToMel(lowFreq)
        val highMel = hzToMel(highFreq)
        val melStep = (highMel - lowMel) / (numFilters + 1)

        val melPoints = DoubleArray(numFilters + 2) { i ->
            melToHz(lowMel + i * melStep)
        }

        val binPoints = IntArray(numFilters + 2) { i ->
            ((fftSize + 1) * melPoints[i] / sampleRate).toInt().coerceIn(0, fftSize / 2)
        }

        val halfSize = fftSize / 2
        return Array(numFilters) { m ->
            val filter = DoubleArray(halfSize)
            val left = binPoints[m]
            val center = binPoints[m + 1]
            val right = binPoints[m + 2]

            for (k in left until center) {
                if (k < halfSize && center > left) {
                    filter[k] = (k - left).toDouble() / (center - left)
                }
            }
            for (k in center until right) {
                if (k < halfSize && right > center) {
                    filter[k] = (right - k).toDouble() / (right - center)
                }
            }
            filter
        }
    }

    private fun hzToMel(hz: Double): Double = 2595.0 * log10(1.0 + hz / 700.0)
    private fun melToHz(mel: Double): Double = 700.0 * (Math.pow(10.0, mel / 2595.0) - 1.0)

    private fun estimatePitchAutocorrelation(frame: DoubleArray, sampleRate: Int): Double {
        val minLag = sampleRate / 400 // Max 400 Hz
        val maxLag = sampleRate / 70  // Min 70 Hz

        var maxCorr = 0.0
        var bestLag = 0

        for (lag in minLag..maxLag.coerceAtMost(frame.size - 1)) {
            var corr = 0.0
            for (i in 0 until frame.size - lag) {
                corr += frame[i] * frame[i + lag]
            }
            if (corr > maxCorr) {
                maxCorr = corr
                bestLag = lag
            }
        }

        return if (bestLag > 0) sampleRate.toDouble() / bestLag else 140.0
    }
}
