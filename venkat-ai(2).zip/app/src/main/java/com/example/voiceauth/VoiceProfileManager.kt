package com.example.voiceauth

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

private const val TAG = "VoiceProfileManager"
private const val PREFS_NAME = "venkat_voice_auth_prefs"
private const val KEY_AUTH_ENABLED = "key_personal_voice_auth_enabled"
private const val KEY_ACCURACY_THRESHOLD = "key_voice_accuracy_threshold"

data class SpeakerVerificationResult(
    val isMatch: Boolean,
    val similarity: Float,
    val threshold: Float,
    val details: String
)

/**
 * Singleton manager for Personal Voice Authentication in VENKAT AI.
 */
class VoiceProfileManager private constructor(private val context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _isAuthEnabled = MutableStateFlow(prefs.getBoolean(KEY_AUTH_ENABLED, false))
    val isAuthEnabled: StateFlow<Boolean> = _isAuthEnabled.asStateFlow()

    private val _accuracyThreshold = MutableStateFlow(prefs.getFloat(KEY_ACCURACY_THRESHOLD, 0.72f))
    val accuracyThreshold: StateFlow<Float> = _accuracyThreshold.asStateFlow()

    private val _activeProfile = MutableStateFlow<VoiceProfile?>(null)
    val activeProfile: StateFlow<VoiceProfile?> = _activeProfile.asStateFlow()

    private val _isRegistered = MutableStateFlow(false)
    val isRegistered: StateFlow<Boolean> = _isRegistered.asStateFlow()

    // Temporary buffer during registration flow
    private val recordedSampleEmbeddings = mutableListOf<FloatArray>()

    init {
        loadProfile()
    }

    fun loadProfile() {
        val loaded = SpeakerVerificationEngine.loadEncryptedProfile(context)
        _activeProfile.value = loaded
        _isRegistered.value = loaded != null
        Log.i(TAG, "Voice profile loaded: ${if (loaded != null) "Registered for ${loaded.speakerName}" else "Not Registered"}")
    }

    fun setAuthEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_AUTH_ENABLED, enabled).apply()
        _isAuthEnabled.value = enabled
        Log.i(TAG, "Personal Voice Authentication toggled: $enabled")
    }

    fun setAccuracyThreshold(threshold: Float) {
        val clamped = threshold.coerceIn(0.50f, 0.95f)
        prefs.edit().putFloat(KEY_ACCURACY_THRESHOLD, clamped).apply()
        _accuracyThreshold.value = clamped
    }

    /**
     * Resets the temporary sample collector for a new registration session.
     */
    fun startRegistration() {
        recordedSampleEmbeddings.clear()
    }

    /**
     * Adds an audio sample chunk during registration.
     */
    fun recordSample(pcmData: ShortArray): Boolean {
        if (pcmData.size < 800) return false
        val embedding = SpeakerVerificationEngine.extractEmbedding(pcmData)
        recordedSampleEmbeddings.add(embedding)
        Log.i(TAG, "Added sample embedding #${recordedSampleEmbeddings.size}")
        return true
    }

    /**
     * Finalizes and saves the multi-sample master profile.
     */
    fun finalizeRegistration(speakerName: String = "Venkat"): Boolean {
        if (recordedSampleEmbeddings.isEmpty()) return false

        val masterProfile = SpeakerVerificationEngine.createMasterProfile(
            samples = recordedSampleEmbeddings,
            speakerName = speakerName
        )

        val saved = SpeakerVerificationEngine.saveEncryptedProfile(context, masterProfile)
        if (saved) {
            _activeProfile.value = masterProfile
            _isRegistered.value = true
            recordedSampleEmbeddings.clear()
            Log.i(TAG, "Registration complete and profile saved successfully.")
            return true
        }
        return false
    }

    /**
     * Deletes the registered voice profile.
     */
    fun deleteProfile(): Boolean {
        val deleted = SpeakerVerificationEngine.deleteProfile(context)
        if (deleted) {
            _activeProfile.value = null
            _isRegistered.value = false
            setAuthEnabled(false)
            Log.i(TAG, "Voice profile deleted.")
        }
        return deleted
    }

    /**
     * Verifies whether an incoming audio frame matches the registered speaker profile.
     */
    fun verifySpeaker(pcmData: ShortArray): SpeakerVerificationResult {
        // Fallback: If auth is disabled, allow
        if (!_isAuthEnabled.value) {
            return SpeakerVerificationResult(
                isMatch = true,
                similarity = 1.0f,
                threshold = _accuracyThreshold.value,
                details = "Personal voice authentication is OFF (Fallback mode)"
            )
        }

        val profile = _activeProfile.value
        if (profile == null) {
            // Profile not registered, can't verify
            return SpeakerVerificationResult(
                isMatch = false,
                similarity = 0.0f,
                threshold = _accuracyThreshold.value,
                details = "Voice profile not registered"
            )
        }

        val incomingEmbedding = SpeakerVerificationEngine.extractEmbedding(pcmData)
        val similarity = SpeakerVerificationEngine.computeSimilarity(profile.embeddingVector, incomingEmbedding)
        val threshold = _accuracyThreshold.value
        val isMatch = similarity >= threshold

        val details = if (isMatch) {
            "Speaker matches registered profile '${profile.speakerName}' (Score: ${String.format("%.1f%%", similarity * 100)})"
        } else {
            "Speaker verification failed! Score: ${String.format("%.1f%%", similarity * 100)} < Threshold: ${String.format("%.1f%%", threshold * 100)}"
        }

        Log.i(TAG, "Verification result: $details")
        return SpeakerVerificationResult(
            isMatch = isMatch,
            similarity = similarity,
            threshold = threshold,
            details = details
        )
    }

    companion object {
        @Volatile
        private var instance: VoiceProfileManager? = null

        fun getInstance(context: Context): VoiceProfileManager {
            return instance ?: synchronized(this) {
                instance ?: VoiceProfileManager(context.applicationContext).also { instance = it }
            }
        }
    }
}
