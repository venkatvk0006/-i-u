package com.example.voiceauth

import org.json.JSONArray
import org.json.JSONObject

/**
 * Encrypted speaker profile storing a 128-dimensional acoustic embedding vector.
 */
data class VoiceProfile(
    val speakerName: String = "Venkat",
    val embeddingVector: FloatArray,
    val sampleCount: Int,
    val registeredTimestamp: Long = System.currentTimeMillis()
) {
    fun toJsonString(): String {
        val json = JSONObject()
        json.put("speakerName", speakerName)
        json.put("sampleCount", sampleCount)
        json.put("registeredTimestamp", registeredTimestamp)

        val array = JSONArray()
        for (v in embeddingVector) {
            array.put(v.toDouble())
        }
        json.put("embedding", array)
        return json.toString()
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as VoiceProfile
        if (speakerName != other.speakerName) return false
        if (!embeddingVector.contentEquals(other.embeddingVector)) return false
        if (sampleCount != other.sampleCount) return false
        if (registeredTimestamp != other.registeredTimestamp) return false

        return true
    }

    override fun hashCode(): Int {
        var result = speakerName.hashCode()
        result = 31 * result + embeddingVector.contentHashCode()
        result = 31 * result + sampleCount
        result = 31 * result + registeredTimestamp.hashCode()
        return result
    }

    companion object {
        fun fromJsonString(jsonStr: String): VoiceProfile? {
            return try {
                val json = JSONObject(jsonStr)
                val name = json.optString("speakerName", "Venkat")
                val samples = json.optInt("sampleCount", 1)
                val timestamp = json.optLong("registeredTimestamp", System.currentTimeMillis())

                val array = json.getJSONArray("embedding")
                val vector = FloatArray(array.length())
                for (i in 0 until array.length()) {
                    vector[i] = array.getDouble(i).toFloat()
                }

                VoiceProfile(
                    speakerName = name,
                    embeddingVector = vector,
                    sampleCount = samples,
                    registeredTimestamp = timestamp
                )
            } catch (e: Exception) {
                null
            }
        }
    }
}
