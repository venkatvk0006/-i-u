package com.example

import android.Manifest
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.calling.ContactCallDialog
import com.example.calling.ContactCallViewModel
import com.example.ui.ChatViewModel
import com.example.ui.MainChatScreen
import com.example.ui.theme.VenkatAiTheme
import com.example.util.configureAppCheck
import com.example.wakeword.WakeWordManager
import com.example.wakeword.WakeWordService

class MainActivity : ComponentActivity() {

    private var activeChatViewModel: ChatViewModel? = null
    private var pendingWakeWordName: String? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val recordAudioGranted = permissions[Manifest.permission.RECORD_AUDIO] == true
        if (recordAudioGranted) {
            val wakeWordManager = WakeWordManager.getInstance(this)
            wakeWordManager.enableWakeWord()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = this
        appContext = applicationContext

        // STEP 1: Mandatory App Check configuration with launch intent before any UI or Firebase operations
        configureAppCheck(this, intent)

        // STEP 2: Edge to edge support & Lock Screen / Screen-On configuration
        enableEdgeToEdge()
        setupLockScreenVisibility()

        // STEP 3: Request permissions for Microphone, Contacts, and Notifications
        requestAssistantPermissions()

        // Auto-start wake-word background service if permissions are already granted
        val wakeWordManager = WakeWordManager.getInstance(this)
        if (wakeWordManager.hasMicrophonePermission()) {
            wakeWordManager.enableWakeWord()
        }

        // STEP 4: Initialize UI
        setContent {
            val viewModel: ChatViewModel = viewModel()
            val contactCallViewModel: ContactCallViewModel = viewModel()
            val reminderViewModel: com.example.reminder.ReminderViewModel = viewModel()
            val themeMode by viewModel.themeMode.collectAsState()

            LaunchedEffect(viewModel) {
                activeChatViewModel = viewModel
                pendingWakeWordName?.let { wakeWord ->
                    pendingWakeWordName = null
                    viewModel.onGlobalWakeWordActivated(wakeWord)
                }
            }

            VenkatAiTheme(themeMode = themeMode) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    MainChatScreen(
                        viewModel = viewModel,
                        contactCallViewModel = contactCallViewModel,
                        reminderViewModel = reminderViewModel
                    )

                    ContactCallDialog(
                        viewModel = contactCallViewModel,
                        ttsHelper = viewModel.ttsHelper,
                        onDismiss = { contactCallViewModel.reset() }
                    )
                }
            }
        }

        // STEP 5: Process wake-up intent if launched from WakeWordService
        handleWakeWordIntent(intent)
    }

    private fun setupLockScreenVisibility() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
            keyguardManager?.requestDismissKeyguard(this, null)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }
    }

    private fun requestAssistantPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        permissionLauncher.launch(permissions.toTypedArray())
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        configureAppCheck(this, intent)
        setupLockScreenVisibility()
        handleWakeWordIntent(intent)
    }

    private fun handleWakeWordIntent(intent: Intent?) {
        val wasTriggeredByWakeWord = intent?.getBooleanExtra(
            WakeWordService.EXTRA_WAKE_WORD_TRIGGERED,
            false
        ) == true

        if (wasTriggeredByWakeWord) {
            val wakeWordName = intent.getStringExtra(WakeWordService.EXTRA_WAKE_WORD_NAME) ?: "Hey Jarvis"
            intent.removeExtra(WakeWordService.EXTRA_WAKE_WORD_TRIGGERED)

            val icon = when {
                wakeWordName.contains("Jarvis", ignoreCase = true) -> "⚡"
                wakeWordName.contains("Siri", ignoreCase = true) -> "🍎"
                wakeWordName.contains("Tamil", ignoreCase = true) -> "✨"
                else -> "🐱"
            }
            Toast.makeText(this, "$icon \"$wakeWordName\" activated! \"Hi Venkat, I am listening.\"", Toast.LENGTH_SHORT).show()

            val vm = activeChatViewModel
            if (vm != null) {
                vm.onGlobalWakeWordActivated(wakeWordName)
            } else {
                pendingWakeWordName = wakeWordName
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) {
            instance = null
        }
        activeChatViewModel = null
    }

    companion object {
        var appContext: Context? = null
        var instance: MainActivity? = null
    }
}
